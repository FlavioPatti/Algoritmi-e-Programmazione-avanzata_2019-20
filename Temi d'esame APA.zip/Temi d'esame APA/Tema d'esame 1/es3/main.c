#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int solveR(char *str, char **dict, int n, int s, int *sol, int pos);
void solve(char *str, char **dict, int n, int s);
int verifica(char *str, char **dict, int n, int s, int *sol);

int main()
{
    char str[12] = "abracadabra";
    int n = 8, i, s = 3;
    char **dict = malloc(n*sizeof(char *));
    for(i=0; i<n; i++) dict[i]=malloc(5*sizeof(char));
    dict[0] = "a";
    dict[1] = "ab";
    dict[2] = "cada";
    dict[3] = "abra";
    dict[4] = "ra";
    dict[5] = "da";
    dict[6] = "ca";
    dict[7] = "bra";

    solve(str, dict, n, s);

    return 0;
}

void solve(char *str, char **dict, int n, int s){
int *sol = malloc(4*sizeof(int));

if(solveR(str,dict,n,s,sol,0) == 0)
    printf("s = %d\n Nessuna soluzione", s);
}

int verifica(char *str, char **dict, int n, int s, int *sol){
    int i,j, count = 0;
    char tmp[12] = "";
    int *mark = calloc(n,sizeof(int));
    for(j=0; j<n; j++){
    for(i=0; i<4; i++){
        if(j == sol[i])
            mark[j]++;
            }
        }
    for(i=0; i<n; i++){
            if(mark[i]>=1) count++;
        }
    if(count!=s) return 0;

    for(i=0; i<4;i++)
    strcat(tmp, dict[sol[i]]);

    if(strcmp(tmp,str)==0) return 1;
    return 0;
}

int solveR(char *str, char **dict, int n, int s, int *sol, int pos){
int i;
if(pos>=4){
    if(verifica(str,dict,n,s,sol)){
       printf("s = %d\n", s);
       for(i=0; i<4; i++)
          printf("%s ", dict[sol[i]]);
            printf("\n");
        return 1;
    }
return 0;
}

for(i=0; i<n; i++){
    sol[pos] = i;
    if(solveR(str,dict,n,s,sol,pos+1)) return 1;
    }
return 0;
}
