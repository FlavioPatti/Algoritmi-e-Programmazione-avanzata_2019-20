#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include "LIST.h"

struct lista_s{
link head;
};

struct node{
int val;
link next;
};

void fu(LIST L, int *v, int n){
link x, p;
int min = ricercaMin(v,n);
    printf("Il valore minimo e': %d\n", min);

for(x = L->head, p = NULL; x!=NULL; p=x, x = x->next){
    if(x->val > min){
        if(x==L->head) L->head = x->next;
        else p->next = x->next;
        }
    }
    stampa(L->head);
}

int ricercaMin(int* v, int n){
    int i, min = INT_MAX;
    for(i=0; i<n;i++){
        if(v[i]<min)
            min = v[i];
        }
return min;
}

LIST newList(link a){
LIST h = malloc(sizeof(*h));
h->head = a;
return h;
}

link newNode(int val, link next){
link x = malloc(sizeof(*x));
x->val = val;
x->next = next;
return x;
}

void stampa(link root){
    if(root==NULL) return;
printf("%d ", root->val);
stampa(root->next);
}
