#include <stdio.h>
#include <stdlib.h>
#include "LIST.h"

int main()
{
    link g = newNode(0, NULL);
    link f = newNode(4, g);
    link e = newNode(1, f);
    link d = newNode(3,e);
    link c = newNode(6, d);
    link b = newNode(10, c);
    link a = newNode(3, b);
    LIST h = newList(a);
    int v[3] = {1,2,3};

    stampa(a);
    printf("\n");
    fu(h,v,3);


    return 0;
}
