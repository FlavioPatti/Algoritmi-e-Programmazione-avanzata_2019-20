#ifndef LIST_H
#define LIST_H

typedef struct lista_s* LIST;
typedef struct node* link;

link newNode(int val, link next);
void stampa(link root);
LIST newList(link a);
void fu(LIST L, int *v, int n);
int ricercaMin(int* v, int n);

#endif


