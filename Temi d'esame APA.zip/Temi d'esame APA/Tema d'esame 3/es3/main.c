#include <stdio.h>
#include <stdlib.h>

typedef struct item_s{
int n_ogg;
char *nome;
int costo;
int valore;
int tipo;
int quantita;
}item_t;

void solve_r(item_t *v, int n, int *sol, int *best_sol, int pos, int costo_max);
int verifica(item_t *v, int n, int *sol, int *best_sol,int costo_max);
int valore = 0;
int main()
{
    item_t v[3];
    v[0].n_ogg =1;
    v[0].nome = "palla";
    v[0].costo = 15;
    v[0].quantita = 4;
    v[0].tipo = 3;
    v[0].valore = 20;

    v[1].n_ogg =2;
    v[1].nome = "gelato";
    v[1].costo = 4;
    v[1].quantita = 25;
    v[1].tipo = 1;
    v[1].valore = 3;

    v[2].n_ogg =3;
    v[2].nome = "letto";
    v[2].costo = 100;
    v[2].quantita = 3;
    v[2].tipo = 8;
    v[2].valore = 75;

    int n = 3, i;
    int *sol = malloc(n*sizeof(int));
    int *best_sol = malloc(n*sizeof(int));

    solve_r(v,n,sol,best_sol,0,50);

    printf("la soluzione ottima e':\n");
    for(i=0; i<n; i++) printf("%d ", best_sol[i]);

    return 0;
}
int verifica(item_t *v, int n, int *sol, int *best_sol,int costo_max){
int i, sum_costo = 0, sum_valore = 0;
for(i=0; i<n; i++){
        if(sol[i]==1){
    sum_costo+= v[i].costo;
    sum_valore+= v[i].valore;
        }
}

if(sum_costo>costo_max) return 0;

if(sum_valore<valore) return 0;
else{
    valore = sum_valore;
    for(i=0; i<n; i++) best_sol[i]=sol[i];
    return 1;
}

}

void solve_r(item_t *v, int n, int *sol, int *best_sol, int pos, int costo_max){
    if(pos>=n){
        if(verifica(v,n,sol,best_sol,costo_max));
        return;
    }

    sol[pos] = 0;
    solve_r(v,n,sol,best_sol,pos+1,costo_max);
    sol[pos] = 1;
    solve_r(v,n,sol,best_sol,pos+1,costo_max);
}
