#include <stdio.h>
#include <stdlib.h>

typedef struct node* link;
struct node{
int x;
int y;
int sum;
link next;
};
typedef struct list_s{
link head;
}list_t;

list_t prodCart(int *v1, int d1, int *v2, int d2);
void stampa(list_t h);
link newNode(int x, int y, int sum, link next);

int main()
{
    int v1[3]={1,2,3};
    int v2[4]={3,4,5,6};
    list_t h = prodCart(v1,3,v2,4);
    stampa(h);

    return 0;
}

link newNode(int x, int y, int sum, link next){
link nodo = malloc(sizeof(*nodo));
nodo->x = x;
nodo->y = y;
nodo->sum = sum;
nodo->next = next;
return nodo;
}

list_t prodCart(int *v1, int d1, int *v2, int d2){
int i,j;
link t, p, x;
list_t h;
h.head = NULL;

for(i=0; i<d1; i++){
    for(j=0; j<d2; j++){
            t = h.head;
            p = t;
            x = newNode(v1[i],v2[j],v1[i]+v2[j], NULL);

            while(t!=NULL && t->sum < x->sum){
                p = t;
                t = t->next;
            }
            if(t==h.head){
                h.head = x;
            }else{
            p->next = x;
            x->next = t;
            }
        }
    }
    return h;
}

void stampa(list_t h){
    link x;
    for(x = h.head; x!=NULL; x= x->next)
    printf("%d %d\n", x->x, x->y);
}
