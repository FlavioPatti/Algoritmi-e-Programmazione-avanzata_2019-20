#include <stdio.h>
#include <stdlib.h>

void powerset(int n, int *v, int *sol, int *best_sol, int pos);
int verifica(int n, int *v, int *sol);
int lunghezza_max = 0;
int main()
{
    int N = 9;
    int V[9] = {4,2,5,9,7,6,10,3,1};
    int *sol = malloc(N*sizeof(int));
    int *best_sol = malloc(N*sizeof(int));

    powerset(N,V,sol,best_sol,0);
    for(int i=0; i<N; i++) {
    if(best_sol[i]==1)
            printf("%d ", V[i]);
    }
    printf("\nlunghezza totale = %d", lunghezza_max--);

    return 0;
}

int verifica(int n, int *v, int *sol){
int i, j=0, *tmp = calloc(n,sizeof(int));
int count = 0, flag = 0;
for(i=0; i<n; i++){
    if(sol[i]==1){
        tmp[j++] = v[i];
    }
}

tmp = realloc(tmp, j*sizeof(int));
for(i=0; i<j-1; i++){
    while(tmp[i]<tmp[i+1]){
            count++;
            i++;
            flag = 1;
             }
    while(tmp[i]>tmp[i+1] && flag ==1){
            count++;
           i++;  }
}

if(lunghezza_max<count){
    lunghezza_max = count;
    return 1;
}
return 0;
}


void powerset(int n, int *v, int *sol, int *best_sol, int pos){
int i;
if(pos>=n){
      if(verifica(n,v,sol) ){
    for(i=0; i<n; i++) best_sol[i]=sol[i];
    return;
      }
    return;
}

sol[pos]=0;
powerset(n,v,sol,best_sol,pos+1);
sol[pos]=1;
powerset(n,v,sol,best_sol,pos+1);

}
