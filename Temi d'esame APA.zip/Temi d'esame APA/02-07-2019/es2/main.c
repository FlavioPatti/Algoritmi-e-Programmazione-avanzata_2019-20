#include <stdio.h>
#include <stdlib.h>
typedef struct node* link;
struct node{
char val;
link next;
};
link newNode(char val, link next);
void stampa(link head);
link purgeList(link head1);

int main()
{
    link s = newNode('f',NULL);
    link r = newNode(')',s);
    link q = newNode('x',r);
    link p = newNode('x',q);
    link o = newNode('(', p);
    link n = newNode('a', o);
    link m = newNode(')', n);
    link l = newNode('(', m);
    link i = newNode('e', l);
    link h = newNode('b', i);
    link g = newNode(')', h);
    link f = newNode('g', g);
    link e = newNode('c', f);
    link d = newNode('a', e);
    link c = newNode('(', d);
    link b = newNode('b', c);
    link a = newNode('a', b);

    stampa(a);
    link A = purgeList(a);
    stampa(A);


    return 0;
}
link purgeList(link head1){
    link t = head1;
    link p = t, x;
    link head2 = NULL, head3 = NULL;
    while(t!=NULL){

    while(p->val != '(' && t!=NULL){
            head2 = newNode(t->val,head2);
            p = t;
            t = t->next;
        }

    if(t!=NULL) head2 = newNode('*',head2);
    while(p->val != ')' && t!=NULL){
        p = t;
        t = t->next;
        }
    if(t!=NULL) head2 = newNode(')',head2);
    }

    for(x= head2; x!=NULL; x= x->next)
    head3 = newNode(x->val, head3);

    return head3;
}

void stampa(link head){
    link x;
for(x = head; x!=NULL; x = x->next) printf("%c ", x->val);
printf("\n");
}

link newNode(char val, link next){
link x = malloc(sizeof(*x));
x->val = val;
x->next = next;
return x;
}
