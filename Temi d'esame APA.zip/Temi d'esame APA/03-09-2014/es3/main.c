#include <stdio.h>
#include <stdlib.h>

typedef struct node_t *link;
struct node_t{
char lettera;
link fratello;
link figlio;
};

link newNode(char lettera, link fratello, link figlio);
void stampa(link a);

int main()
{
    link j = newNode('j', NULL, NULL);
    link i = newNode('i', j, NULL);
    link h = newNode('h', i, NULL);
    link e = newNode('e', NULL, h);
    link g = newNode('g', NULL, NULL);
    link f = newNode('f', g, NULL);
    link d = newNode('d', NULL, f);
    link c = newNode('c', d, NULL);
    link b = newNode('b', c, e);
    link a = newNode('a', NULL, b);

    stampa(a);

    return 0;
}

void stampa(link a){

printf("%c\n", a->lettera);
if(a->figlio!=NULL)
    stampa(a->figlio);
if(a->fratello!=NULL)
    stampa(a->fratello);

}

link newNode(char lettera, link fratello, link figlio){
link x = malloc(sizeof(*x));
x->lettera = lettera;
x->figlio = figlio;
x->fratello = fratello;
return x;
}
