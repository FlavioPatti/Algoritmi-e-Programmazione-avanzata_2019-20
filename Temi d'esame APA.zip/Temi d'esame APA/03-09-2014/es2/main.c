#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node_t *link;

struct node_t{
char *parola;
link next;
};

typedef struct lista_s{
link head;
}lista_t;

link splitStr (char *str);
char *sottostringa(char * str);
lista_t *l;
int next = 0;

int main()
{
    char stringa[50] = {"Ciao.amore.ti.amo.tanto.<3"};
    link x;
    l = malloc(sizeof(*l));
    l->head = NULL;

    l->head = splitStr(stringa);
    l->head = splitStr(stringa);
    l->head = splitStr(stringa);
    l->head = splitStr(stringa);
    l->head = splitStr(stringa);
    l->head = splitStr(stringa);

    for(x=l->head; x!=NULL; x=x->next) printf("%s ", x->parola);

    return 0;
}

link splitStr (char *str){
char * tmp = calloc(10,sizeof(char));
link x = malloc(sizeof(*x));

tmp = sottostringa(str);

x->parola = strdup(tmp);
x->next = l->head;

return x;
}

char *sottostringa(char * str){

char *tmp = calloc(10,sizeof(char));
int i, j=0;

 for(i=next; i<strlen(str); i++){
    if(str[i]!='.'){
        tmp[j++] = str[i];
    }else{
        next = ++i;
        tmp[j] = '\0';
        break;
    }
 }
 return tmp;

}

