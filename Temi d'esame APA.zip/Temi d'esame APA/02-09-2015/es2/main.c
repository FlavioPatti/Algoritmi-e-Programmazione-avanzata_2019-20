#include <stdio.h>
#include <stdlib.h>

typedef struct node *link;
struct node{
int val;
link sx;
link dx;
};

/*
   a1
  / \
 b2    c3
/\     \
d4 e5     f6

   a
  / \
 b    c
  \     \
   e     f

*/

int TREEisomorph(link t1, link t2);
link newNode(int val, link sx, link dx);

int main()
{
    link d = newNode(4, NULL, NULL);
    link e = newNode(5, NULL, NULL);
    link f = newNode(6, NULL, NULL);
    link b = newNode(2, d, e);
    link c = newNode(3, NULL, f);
    link a = newNode(1, b, c);

    link d1 = newNode(4, NULL, NULL);
    link e1 = newNode(5, NULL, NULL);
    link f1 = newNode(6, NULL, NULL);
    link b1 = newNode(2, d1, e1);
    link c1 = newNode(3, NULL, f1);
    link a1 = newNode(1, b1, c1);

    printf("%d", TREEisomorph(a, a1) );

    return 0;
}

int TREEisomorph(link t1, link t2){

if(t2 == NULL && t1 == NULL ) return 1;
if( (t2!=NULL && t1 == NULL ) || (t1!=NULL && t2 ==NULL) ) return 0;

	if(t1->val == t2->val)
		return TREEisomorph(t1->sx, t2->sx) && TREEisomorph(t1->dx, t2->dx);
	else return 0;

}

link newNode(int val, link sx, link dx){
link x =malloc(sizeof(x));
x->val = val;
x->sx = sx;
x->dx = dx;
return x;
}
