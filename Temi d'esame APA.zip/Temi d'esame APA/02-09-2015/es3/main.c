#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define N 3

int best_somma = 0, best_lunghezza = INT_MAX;
void camminoMat(int mat[N][N], int mark[N][N], int *dx, int *dy, int x_corr, int y_corr, int x_fin, int y_fin, int *path, int pos, int somma);

int main()
{
    int mat[N][N] = { {1,2,-3}, {9,-9,7}, {0,1,4} };
    int mark[N][N] = {0};
    int *path = calloc(N*N, sizeof(int));
    int dx[8], dy[8];
    dx[0]= 0;
    dy[0]=-1;  //alto
    dx[1]=0;
    dy[1]=1; //basso
    dx[2]=1;
    dy[2]=0; //destra
    dx[3]=-1;
    dy[3]=0; //sinistra
    dx[4]=-1;
    dy[4]=-1; //a-s
    dx[5]=1;
    dy[5]=1;  //b-d
    dx[6]=-1;
    dy[6]=1; //b-s
    dx[7]=1;
    dy[7]=-1; //a-d

    camminoMat(mat,mark,dx,dy, 0, 0, N-1, N-1, path, 0, 0);

    printf("somma totale: %d, lunghezza totale: %d", best_somma, best_lunghezza);

    return 0;
}

void camminoMat(int mat[N][N], int mark[N][N], int *dx, int *dy, int x_corr, int y_corr, int x_fin, int y_fin, int *path, int pos, int somma){
int i;

if(x_corr==x_fin && y_corr==y_fin){
        for(i=0; i<pos; i++) somma+=path[i];
        if(somma>best_somma || (somma==best_somma && pos<best_lunghezza) ){
            best_somma = somma;
            best_lunghezza = pos;
        }
        return;
}

for(i=0; i<8; i++) {
            x_corr = x_corr + dx[i];
            y_corr = y_corr + dy[i];
        if(x_corr<N && x_corr>=0 && y_corr<N && y_corr>=0){
            if(mark[x_corr][y_corr]==0){
            mark[x_corr][y_corr]=1;
            path[pos]= mat[x_corr][y_corr];
            camminoMat(mat, mark, dx, dy, x_corr, y_corr, x_fin, y_fin, path, pos+1, somma);
             mark[x_corr][y_corr] = 0;
            }
        }
    }
    return;
}
