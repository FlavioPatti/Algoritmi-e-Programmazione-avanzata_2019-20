#include <stdio.h>
#include <stdlib.h>

int birthday (int *vet, int n, int m, int k);
int comb_sempl(int *vet, int *sol, int n, int k, int m, int pos, int start);
int verifica(int *vet, int *sol, int n, int k, int m);
int count = 0;
int main()
{
    int k = 3; //numero libri da comprare
    int n = 5; //numero libri disponibili
    int m = 4; //numero generi diversi dei libri
    int *vet = malloc(n*sizeof(int));
    vet[0] = 2; //libro 0 genere 2
    vet[1] = 1; //libro 1 genere 1
    vet[2] = 1; //libro 2 genere 1
    vet[3] = 4; //libro 3 genere 4
    vet[4] = 3; //libro 4 genere 3

    printf("soluzioni trovate: %d", birthday(vet,n,m,k));


    return 0;
}

int birthday (int *vet, int n, int m, int k){
int *sol = malloc(k*sizeof(int));

return comb_sempl(vet,sol,n,k,m, 0, 0);
}
int verifica(int *vet, int *sol, int n, int k, int m){
int i;
int *mark = calloc(m,sizeof(int));
for(i=0; i<k; i++)
    mark[vet[sol[i]]-1]++;

for(i=0; i<m; i++)
    if(mark[i]>=2) return 0;

return 1;
}

int comb_sempl(int *vet, int *sol,int n, int k, int m, int pos, int start){
int i;
if(pos>=k){
    if(verifica(vet,sol, n,k,m)){
            count++;
        for(i=0; i<k; i++) printf("%d", sol[i]);
        printf("\n");
    }
    return count;
}
for(i=start; i<n; i++){
    sol[pos]=i;
    count = comb_sempl(vet,sol,n,k,m,pos+1,i+1);
    }
    return count;
}
