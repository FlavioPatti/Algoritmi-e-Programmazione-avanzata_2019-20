#include <stdio.h>
#include <stdlib.h>
typedef struct node* link;
struct node{
int val;
link sx;
link dx;
};

link newNode(int val, link sx, link dx);
int distance (link root, int key1, int key2);
int distance_R(link root, int key1, int key);
int count = 0;
int main()
{   link h = newNode(17,NULL,NULL);
    link g = newNode(12,NULL,NULL);
    link d = newNode(1,NULL,NULL);
    link e = newNode(15,g,h);
    link f = newNode(23,NULL,NULL);
    link b = newNode(10,d,e);
    link c = newNode(20,NULL, f);
    link a = newNode(18,b,c);

    printf("%d\n", distance_R(a, 18, 23));

    return 0;
}

int distance (link root, int key1, int key2){

    if(root->val == key2)
    return count;

   if(key2 > root->val)
        return count = 1 + distance(root->dx,key1,key2);
    if(key2 < root->val)
        return count = 1 + distance(root->sx,key1,key2);

    return count;
}
int distance_R(link root, int key1, int key2){
    if( key1 == root->val)
        return distance(root, key1, key2);
    if(root->val<key1) distance_R(root->dx, key1,key2);
    if(root->val>key1) distance_R(root->sx, key1,key2);
}

link newNode(int val, link sx, link dx){
link x = malloc(sizeof(*x));
x->val = val;
x->sx = sx;
x->dx = dx;
return x;
}
