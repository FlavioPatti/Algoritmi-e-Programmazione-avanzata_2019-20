#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void decomponi(char *str, int num, int *lungh);
void trovaSottostringhe(char *str, int num, int *lungh, int *sol, int pos, int sum);
int flag = 0;
int main()
{   char str[30]={"tentativo"};
    int num = 3;
    int lungh[3]= {2,5,7};

    decomponi(str, num, lungh);

    return 0;
}

void decomponi(char *str, int num, int *lungh){
    int *sol = malloc(num*sizeof(int));

   trovaSottostringhe(str,num,lungh,sol,0, 0);

}

void trovaSottostringhe(char *str, int num, int *lungh, int *sol, int pos, int sum){
int i, j;

if(pos>=num && flag ==0){
    for(i=0;i<num;i++)
    sum+=sol[i];
    if(sum == strlen(str)){
        printf("trovata soluzione:\n");
        for(j=0; j<num; j++)
        printf("%d ", sol[j]);
        flag = 1;
    }

 return;
}

for(i=0; i<num; i++){
    sol[pos]=lungh[i];
    trovaSottostringhe(str, num, lungh, sol, pos+1, sum);
  }

}
