#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct colonna *link;
typedef struct riga *next;
struct colonna{
	int val;
	int col;
	link prox_col;
};

struct riga{
	link head;
	next prox_rig;
	int r;
};

link newColonna(int val, int col, link prox_col);
next newRiga(int r, link head, next prox_rig);

int main()
{

   link b = newColonna(4,4,NULL);
   link a = newColonna(5,3,b);
   next A = newRiga(0,a,NULL);
   printf("%d", A->head->val);

   link e = newColonna(12,3,NULL);
   link d = newColonna(11,2,e);
   link c = newColonna(10,1,d);
   next B = newRiga(1,c,A);
   printf("%d", B->head->val);


}
link newColonna(int val, int col, link prox_col){
link x = malloc(sizeof(struct colonna));
x->val = val;
x->col = col;
x->prox_col = prox_col;
return x;
}
next newRiga(int r, link head, next prox_rig){
next x = malloc(sizeof(struct riga));
x->r = r;
x->head = head;
x->prox_rig = prox_rig;
return x;
}
