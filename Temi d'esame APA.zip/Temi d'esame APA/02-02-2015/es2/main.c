#include <stdio.h>
#include <stdlib.h>
#define N 3
/*
      a1    l0
     / | \
  b2  c3  d4  l1
  /\   |   |\
 e5 f6 g7 h8 i9  l2
 /           /|\
l10       m11 n12 o13 l3
*/

typedef struct node *link;
struct node {
 int key;
 link children[N];
};
link newNode(int chiave, link c1, link c2, link c3);
void visitaInProfondita(link root);
void visitLevelByLevel (link root, int l1, int l2);
void printAmpiezza(link root, int start, int flag);

int main()
{   link o = newNode(13, NULL, NULL, NULL);
    link n = newNode(12, NULL, NULL, NULL);
    link m = newNode(11, NULL, NULL, NULL);
    link l = newNode(10, NULL, NULL, NULL);
    link i = newNode(9, m,n,o);
    link h = newNode(8, NULL, NULL, NULL);
    link g = newNode(7, NULL, NULL, NULL);
    link f = newNode(6, NULL, NULL, NULL);
    link e = newNode(5, l, NULL, NULL);
    link d = newNode(4, NULL, h, i);
    link c = newNode(3, NULL, g, NULL);
    link b = newNode(2, e, NULL, f);
    link a = newNode(1, b,c,d);
    printf("visita in profondita:\n");
    visitaInProfondita(a);
    printf("\n visito l'albero dal l0 a l1\n");
    visitLevelByLevel(a, 0, 1);
    printf("\n visito l'albero dal l0 a l2\n");
    visitLevelByLevel(a, 0, 2);
    printf("\n visito l'albero dal l1 a l2\n");
    visitLevelByLevel(a, 1, 2);
    printf("\n visito l'albero dal l1 a l3\n");
    visitLevelByLevel(a, 1, 3);
    printf("\n visito l'albero dal l2 a l3\n");
    visitLevelByLevel(a, 2, 3);


    return 0;
}
void visitaInProfondita(link root){
    int i;
    printf("%d ", root->key);
    for(i=0; i<N; i++){
            if(root->children[i]!=NULL){
        visitaInProfondita(root->children[i]);
            }
        }
}
void visitLevelByLevel (link root, int l1, int l2){
    int i;
    for(i =l1; i<=l2; i++) printAmpiezza(root, i, 0);
}

void printAmpiezza(link root, int start, int flag){
    int j;

if(flag==start){
        printf("%d ", root->key);
}else{
    for(j=0; j<N; j++){
        if(root->children[j]!=NULL){
    printAmpiezza(root->children[j], start, flag+1);
        }
    }
}

}

link newNode(int chiave, link c1, link c2, link c3){
    link x = malloc(sizeof(*x));
    x->key = chiave;
    x->children[0] = c1;
    x->children[1] = c2;
    x->children[2] = c3;
    return x;
}
