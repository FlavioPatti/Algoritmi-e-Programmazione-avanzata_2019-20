#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void princ_molt(char **set, int n, int k, int pos, char *sol);

int main()
{
    char **set;
    int n, i;
    char *sol = malloc(30*sizeof(char));
    FILE *fp;
    fp=fopen("sigla.txt", "r");
    if(fp==NULL){
        printf("errore apertura file");
        return -1;
    }
    fscanf(fp,"%d", &n);
    set = malloc(n*sizeof(char *));
    for(i=0; i<n; i++) set[i]=malloc(30*sizeof(char));
    for(i=0; i<n; i++){
        fscanf(fp, "%s", set[i]);
    }
    fclose(fp);

    princ_molt(set, n, 3, 0, sol);

    return 0;
}
void princ_molt(char **set, int n, int k, int pos, char *sol){
    int i;
if(pos>=k){
        printf("%s\n", sol);
        return;
}
for(i=0; i<strlen(set[pos]); i++){
    sol[pos]=set[pos][i];
    princ_molt(set, n, k, pos+1, sol);
    }
    return;
}
