#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 20

void eraseDuplicate (char *str);

int main()
{
    char str[N]=  "aaa;bbba;;cffdaaaab";

    eraseDuplicate(str);

    return 0;
}
                        //i
void eraseDuplicate (char *str){
    int i=0, j=0, k=0, z=0, nuovo;
    char *tmp = malloc(N*sizeof(char)); //j
    char *mark = calloc(N,sizeof(char));//k

    //inserisco il primo
    tmp[j++]=str[i];
    mark[k++]=str[i];
    i++;

    while(str[i]!='\0'){
        nuovo = 1;
        for(z=0; z<k; z++){
            if(str[i]==mark[z])
                nuovo = 0;
        }
        if(nuovo){
            tmp[j++]=str[i];
            mark[k++]=str[i];
            i++;
            }
            else
            i++;
    }
    printf("la stringa dopo aver tolto tutti i caratteri duplicati e'\n");
    for(i=0; i<k;i++)
        printf("%c ", tmp[i]);

    str = realloc(str, k*sizeof(char));
    for(i=0; i<k; i++)
        str[i]=tmp[i];
    }

