#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void perm_rip(char **set, char *sol, int n, int pos, int *mark_alpha, int *mark_num, FILE *fp);

int main(int argc, char *argv[])
{
    char **set;
    int n = 6, k=2, i, j;
    char *sol = malloc(5*sizeof(char));
    int *mark_alpha = malloc(21*sizeof(int));
    int *mark_num = malloc(10*sizeof(int));
    FILE *fp;
    set = malloc(k*sizeof(char *));
    set[0] = malloc(21*sizeof(char));
    set[1] = malloc(10*sizeof(char));

    fp=fopen("password.txt", "r");
    if(fp==NULL){
        printf("errore apertura file in");
        return -1;
    }
    fscanf(fp, "%s", set[0]);
    fscanf(fp, "%s", set[1]);

    fclose(fp);
    for(i=0; i<=21; i++) mark_alpha[i]=k;
    for(j=0; j<=10; j++) mark_num[j]=k;

    printf("%s %s\n", set[0], set[1]);

    fp = fopen(argv[1], "w");

    perm_rip(set, sol, n, 0, mark_alpha, mark_num, fp);

    fclose(fp);

    return 0;
}

void perm_rip(char **set, char *sol, int n, int pos, int *mark_alpha, int *mark_num, FILE *fp){
int i,j;
if(pos>=n){
    for(i=0; i<n; i++) fprintf(fp, "%c", sol[i]);
    fprintf(fp, "\n");
    return;
}
for(i=0; i<strlen(set[0]); i++){
        sol[pos]=set[0][i];
        perm_rip(set, sol, n, pos+1, mark_alpha, mark_num, fp);
        }

    return;
}

