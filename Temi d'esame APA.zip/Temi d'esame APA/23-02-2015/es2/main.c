#include <stdio.h>
#include <stdlib.h>

typedef struct node *link;
struct node {
 int key;
 link sx;
 link dx;
};

link newNode(int chiave, link sx, link dx);
void printPaths (link root, int h, int i, int *ris);

/*
      a1    l0
     / \
  b2     c7   l1
  /\      \
 d3 l6      g8  l2
 /         /\
e4      h9  i10  l3
*/

int main()
{   link e = newNode(4, NULL, NULL);
    link h = newNode(9, NULL, NULL);
    link i = newNode(10, NULL, NULL);
    link d = newNode(3, e,NULL);
    link l = newNode(6, NULL, NULL);
    link g = newNode(8, h,i);
    link b = newNode(2, d,l);
    link c = newNode(7, NULL, g);
    link a = newNode(1, b,c);

    int *ris = malloc(3*sizeof(int));

    printPaths(a, 3, 0, ris);

    return 0;
}
void printPaths (link root, int h, int i, int *ris){
    int j;

    ris[i]=root->key;
    if(root->sx == NULL && root->dx == NULL){
        for(j=0; j<=3; j++){
                if(ris[j]!= -1){
                        printf("%d ", ris[j]);
                }
        }
        printf("\n");
        ris[i] = -1;
        return;
    }
    if(root->sx!=NULL)
printPaths(root->sx, 3, i+1, ris);
    if(root->dx!=NULL)
printPaths(root->dx, 3, i+1, ris);

}

link newNode(int chiave, link sx, link dx){
    link x = malloc(sizeof(*x));
    x->key = chiave;
    x->sx = sx;
    x->dx = dx;
    return x;
}
