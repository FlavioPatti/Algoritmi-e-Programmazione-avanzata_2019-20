#include <stdio.h>
#include <stdlib.h>

int perm_rip(int *val, int *disp, int n, int r, int k, int *sol, int pos);
int verifica(int *val, int *sol,int r, int k);

int main()
{
    int n = 3;
    int val[3]={1,10,25};
    int disp[3]={10, 3, 2};
    int *sol;
    int r = 30;
    int k, trovato = 0, tot = 0, i;
    for(i=0; i<n; i++) tot+=disp[i];

    for(k=1; k<=tot && trovato ==0; k++ ){
            printf("cardinalita %d\n", k);
        sol = malloc(k*sizeof(int));
        if(perm_rip(val,disp,n,r,k,sol,0))
            trovato = 1;
    }
    return 0;
}
int verifica(int *val, int *sol,int r, int k){
int i, sum = 0;
for(i=0; i<k; i++) sum += sol[i];
if(sum==r) return 1;
return 0;
}

int perm_rip(int *val, int *disp, int n, int r, int k, int *sol, int pos){
int i;
if(pos>=k){
    if(verifica(val,sol,r,k)){
        for(i=0; i<k; i++) printf("%d ", sol[i]);
        printf("\n");
        return 1;
    }
    return 0;
}

for(i=0; i<n;i++){
    if(disp[i]>0){
        disp[i]--;
        sol[pos]=val[i];
       if(perm_rip(val,disp,n,r,k,sol,pos+1)) return 1;
        disp[i]++;
        }
    }
    return 0;
}
