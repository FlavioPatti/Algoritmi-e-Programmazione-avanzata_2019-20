#include <stdio.h>
#include <stdlib.h>

typedef struct node* link;
struct node {
     int item;
     link left;
     link  right;
     };
link NEW(int chiave, link left, link  right);
void visitInOrder(link root);
link buildTree(int *inorder, int *preorder, int N);
link buildTreeR(int *inorder, int *preorder, int *i, int l, int r);

int main()
{
    int inorder[11]= {10,100,13,25,3,55,0,14,20,30,90};
    int preorder[11]= {100,10,55,25,13,3,30,14,0,20,90};

    link a = buildTree(inorder,preorder,10);
    visitInOrder(a);

    return 0;
}

link buildTreeR(int *inorder, int *preorder, int *i, int l, int r){
    link root;
    int trovato = 1, j;

    if(l==r){
        root = NEW(preorder[*i],NULL,NULL);
        (*i)++;
        return root;
    }

    for(j= l;j<r && trovato; j++){
        if(preorder[*i] == inorder[j]){
            trovato = 0;
            root = NEW(preorder[*i],NULL,NULL);
            (*i)++;
            root->left = buildTreeR(inorder,preorder,i,l,j-1);
            root->right = buildTreeR(inorder,preorder,i,j+1,r);
        }
    }
    return root;
}

link buildTree(int *inorder, int *preorder, int N){
    int i=0;
    link root;

    root = buildTreeR(inorder,preorder,&i,0,N);

    return root;
}

void visitInOrder(link root){
    if(root==NULL) return;
    printf("%d ", root->item);
visitInOrder(root->left);
visitInOrder(root->right);
}

link NEW(int chiave, link left, link  right) {
    link x = malloc(sizeof *x);
    x->item = chiave;
    x->left = left;
    x->right = right;
    return x;
}
