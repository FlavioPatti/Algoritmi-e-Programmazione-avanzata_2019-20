#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{
   link d = newNode(7,NULL);
   link c = newNode(5,d);
   link b = newNode(3, c);
   link a = newNode(1,b);
   LIST l1 = newList(a);
   stampa(l1);

   link C = newNode(9,NULL);
   link B = newNode(4, C);
   link A = newNode(7,B);
   LIST l2 = newList(A);
   stampa(l2);

   splice(l1, l2, 1, 2);
   stampa(l1);
   stampa(l2);

    return 0;
}
