#ifndef LISTA_H
#define LISTA_H

typedef struct lista_s * LIST;
typedef struct node* link;

link newNode(int val, link next);
void stampa(LIST l);
LIST newList(link root);
void splice (LIST L1, LIST L2, int start, int num);

#endif // LISTA_H
