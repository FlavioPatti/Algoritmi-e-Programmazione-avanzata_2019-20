#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

struct lista_s{
link head;
};

struct node{
int val;
link next;
};

void splice (LIST L1, LIST L2, int start, int num){
link x, y = L2->head;
link t, p;
int s = start;
while(num!=0){
    x = newNode(y->val,NULL);
    y = y->next;
    L2->head = y;
    num--;
    t = L1->head;
    p = t;
    while(t!=NULL && start>=0){
        p = t;
        t = t->next;
        start--;
    }
    start = s+1;
    if(t==L1->head){
        x->next = L1->head;
        L1->head = x;
    }else{
    p->next = x;
    x->next = t;
    }
}



}

LIST newList(link root){
LIST l = malloc(sizeof(*l));
l->head = root;
return l;
}

link newNode(int val, link next){
link x = malloc(sizeof(*x));
x->val = val;
x->next = next;
return x;
}

void stampa(LIST l){
link x;
for(x=l->head; x!=NULL; x= x->next) printf("%d ", x->val);
printf("\n");
}
