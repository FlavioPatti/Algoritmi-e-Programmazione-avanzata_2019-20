#include <stdio.h>
#include <stdlib.h>

void comb_sempl(int n, int *lunghezza, int *prezzo, int *sol, int pos, int start, int k);
int prezzo_max = 0;
int main()
{   int n = 4, k;
    int lunghezza[4]={1,2,3,4};
    int prezzo[4]={1,5,8,9};
    int *sol;
    for(k=1; k<=n; k++){
        sol = malloc(k*sizeof(int));
        comb_sempl(n,lunghezza,prezzo,sol,0,0,k);
    }


    return 0;
}

int verifica(int n, int *lunghezza, int *prezzo, int *sol, int k){
int i, prez = 0, res= 0, res2;
for(i=k-1; i>=0; i--){
    res = n-res-sol[i];
    if(res>res2) break;
    prez += prezzo[res-1];
    res2 = res;
}
if(prez>=prezzo_max){
    prezzo_max = prez;
    return 1;
}

return 0;
}

void comb_sempl(int n, int *lunghezza, int *prezzo, int *sol, int pos, int start, int k){
int i;
if(pos>=k){
        if(sol[0]!=0) return;
    if(verifica(n,lunghezza,prezzo,sol,k)){
    for(i=0; i<k; i++) printf("%d ", sol[i]);
    printf("\n");
    }
    return;
}

for(i = start; i<n; i++){
    sol[pos]=lunghezza[i]-1;
    comb_sempl(n,lunghezza,prezzo,sol,pos+1,i+1,k);
}

}
