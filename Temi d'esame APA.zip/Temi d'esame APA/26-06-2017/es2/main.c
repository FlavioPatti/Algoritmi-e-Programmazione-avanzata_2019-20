#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

typedef struct list1_s{
char *nome_concessionario;
float prezzo;
struct list1_s* prox_nodo;
}list1_t;

typedef struct bst_s{
char *nome_modello;
struct bst_s* sx;
struct bst_s* dx;
list1_t* head;
}bst_t;

typedef struct list2_s{
char *nome_modello;
char *nome_concessionario;
float prezzo;
struct list2_s* prox_nodo;
}list2_t;

bst_t* newBst(char *nome_modello, bst_t* sx, bst_t* dx, list1_t* head);
list1_t* newNode(char *nome_concessionario, float prezzo, list1_t* prox_nodo);
list2_t* newLista(char *nome_modello, char *nome_concessionario, float prezzo, list2_t* prox_nodo);
void bst2list(bst_t *bst, list2_t **head, list2_t **tail);

int main()
{
    list2_t* head = NULL;
    list2_t* tail = NULL;

    list1_t* e = newNode("C4", 6.0, NULL);
    list1_t* c = newNode("C4", 80.0, NULL);
    list1_t* d = newNode("C2", 70.0, c);
    list1_t* b = newNode("C2", 30.0, NULL);
    list1_t* a = newNode("C1", 15.0, b);

    bst_t* C = newBst("Tojota", NULL,NULL, e);
    bst_t* B = newBst("Alpha", NULL,NULL,d);
    bst_t* A = newBst("Fiat", B,C,a);

    printf("%s %s %s\n", A->nome_modello, A->head->nome_concessionario, A->head->prox_nodo->nome_concessionario);
    printf("%s %s %s\n", A->sx->nome_modello, A->sx->head->nome_concessionario, A->sx->head->prox_nodo->nome_concessionario);
    printf("%s %s\n", A->dx->nome_modello, A->dx->head->nome_concessionario);

    bst2list(A,&head,&tail);

    printf("%s %s %0.2f\n", head->nome_modello, head->nome_concessionario, head->prezzo);
    printf("%s %s %0.2f\n", head->prox_nodo->nome_modello, head->prox_nodo->nome_concessionario, head->prox_nodo->prezzo);
    printf("%s %s %0.2f\n", head->prox_nodo->prox_nodo->nome_modello, head->prox_nodo->prox_nodo->nome_concessionario, head->prox_nodo->prox_nodo->prezzo);

    return 0;
}

void bst2list(bst_t *bst, list2_t **head, list2_t **tail){
    list2_t* x;
    list1_t* y;
    int min = INT_MAX;
    char* nome_conc = NULL;
if(bst == NULL) return;

bst2list(bst->sx, head, tail);

for(y = bst->head; y!=NULL; y = y->prox_nodo){
    if(min>y->prezzo){
        min = y->prezzo;
        nome_conc = strdup(y->nome_concessionario);
        }
    }
    x = newLista(bst->nome_modello, nome_conc, min, NULL);
    if((*tail)==NULL && (*head)==NULL){
        (*head) = (*tail) = x;
    }else{
        (*tail)->prox_nodo = x;
        (*tail) = x;
    }

bst2list(bst->dx, head, tail);
}

list2_t* newLista(char *nome_modello, char *nome_concessionario, float prezzo, list2_t* prox_nodo){
list2_t* x = malloc(sizeof(*x));
x->nome_modello = strdup(nome_modello);
x->nome_concessionario = strdup(nome_concessionario);
x->prezzo = prezzo;
x->prox_nodo = prox_nodo;
return x;
}


bst_t* newBst(char *nome_modello, bst_t* sx, bst_t* dx, list1_t* head){
bst_t* x = malloc(sizeof(*x));
x->nome_modello = strdup(nome_modello);
x->sx = sx;
x->dx = dx;
x->head = head;
return x;
}

list1_t* newNode(char *nome_concessionario, float prezzo, list1_t* prox_nodo){
list1_t* x = malloc(sizeof(*x));
x->nome_concessionario = strdup(nome_concessionario);
x->prezzo = prezzo;
x->prox_nodo = prox_nodo;
return x;
}
