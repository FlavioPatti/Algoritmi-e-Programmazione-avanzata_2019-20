#include <stdio.h>
#include <stdlib.h>
int verifica(int *sol, int k, int card);
int powerset(int pos, int *sol, int r, int c, int k, int mat[][c], int card, int start, int riga);

int main()
{
    int mat[3][4] = { {2,3,1,2}, {6,4,2,5}, {2,4,3,2} };
    int r = 3;
    int c = 4;
    int k = 10;
    int i, trovato = 0;
    int *sol;

        printf("Cardinalita minima: ");
        for(i=1;i<=r*c && trovato == 0; i++){
        sol = malloc(i*sizeof(int));
        if(powerset(0,sol,r,c,k,mat,i,0,0))
            trovato = 1;
        }
    trovato = 0;
    printf("Cardinalita massima: ");
    for(i=r*c; i>0 && trovato ==0; i--){
        sol = malloc(i*sizeof(int));
        if(powerset(0,sol,r,c,k,mat,i,0,0))
            trovato = 1;
        }

    return 0;
}

int verifica(int *sol, int k, int card){
int sum = 0;
int i;
for(i=0; i<card; i++) sum = sum + sol[i];
if(sum==k) return 1;
return 0;
}

int powerset(int pos, int *sol, int r, int c, int k, int mat[][c], int card, int start, int riga){
  int i,j;
    if(pos>=card){
        if(verifica(sol,k, card)){
                for(i=0; i<card; i++) printf("%d ", sol[i]);
            printf("\n");
            return 1;
        }
        return 0;
    }
if(start>=c){
        riga++;
        start = 0;
}
for(i=riga; i<r; i++){
    for(j=start; j<c; j++){
        sol[pos]=mat[i][j];
if(powerset(pos+1,sol,r,c,k,mat,card,j+1,riga))
    return 1;
    }
}
    return 0;
}
