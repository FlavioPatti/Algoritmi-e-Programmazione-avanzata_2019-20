#include <stdio.h>
#include <stdlib.h>

void powerset(int n, int *v, int *sol, int *best_sol, int pos);
int verifica(int n, int *v, int *sol);
int lunghezza_max = 0;
int main()
{
    int N = 9;
    int V[9] = {8,9,6,4,5,7,3,2,4};
    int *sol = malloc(N*sizeof(int));
    int *best_sol = malloc(N*sizeof(int));

    powerset(N,V,sol,best_sol,0);
    for(int i=0; i<N; i++) {
    if(best_sol[i]==1)
            printf("%d ", V[i]);
    }

    return 0;
}

int verifica(int n, int *v, int *sol){
int i, j=0, *tmp = calloc(n,sizeof(int));
for(i=0; i<n; i++){
    if(sol[i]==1){
        tmp[j++] = v[i];
    }
}

tmp = realloc(tmp, j*sizeof(int));
for(i=0; i<j-1; i++){
        if(i%2==0){
    if(tmp[i]>=tmp[i+1]) return 0;
    }else{
    if(tmp[i]<=tmp[i+1]) return 0;
    }
}

if(lunghezza_max<j){
    lunghezza_max = j;
    return 1;
}
return 0;
}


void powerset(int n, int *v, int *sol, int *best_sol, int pos){
int i;
if(pos>=n){
      if(verifica(n,v,sol) ){
    for(i=0; i<n; i++) best_sol[i]=sol[i];
    return;
      }
    return;
}

sol[pos]=0;
powerset(n,v,sol,best_sol,pos+1);
sol[pos]=1;
powerset(n,v,sol,best_sol,pos+1);

}
