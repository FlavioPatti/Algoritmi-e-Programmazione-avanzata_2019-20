#include <stdio.h>
#include <stdlib.h>
#define k 3
typedef struct nodo_t* link;

struct nodo_t{
int val;
float peso;
link figli[k];
};

void maxSum(link root, float *maxwt);
link newNode(int val, float peso, link f1, link f2, link f3);
void calcolaSum(link root, float *sum);
void stampa(link root);

int main()
{
        link o = newNode(12,2.8,NULL,NULL,NULL);
        link n = newNode(11,2,NULL,NULL,NULL);
        link m = newNode(10,-3.1, NULL,NULL,NULL);
        link l = newNode(9,-5,NULL,NULL,NULL);
        link i = newNode(8,2.4,NULL,NULL,NULL);
        link e = newNode(4,-20.9, NULL,NULL,NULL);
        link f = newNode(5,-4,NULL,NULL,NULL);
        link g = newNode(6,5.3,i,l,NULL);
        link h = newNode(7,-10.8,m,n,o);
        link d = newNode(3,7.27,h,NULL,NULL);
        link c = newNode(2,3,g,NULL,NULL);
        link b = newNode(1,-8.1,e,f,NULL);
        link a = newNode(0,15.2,b,c,d);
        float *maxwt = calloc(13,sizeof(float));

        stampa(a);
        printf("\n");
        maxSum(a, maxwt);
        for(int i=0; i<13; i++) printf("%0.2f ", maxwt[i]);

    return 0;
}

void maxSum(link root, float *maxwt){
    float sum = 0.0;
    int i;

    if(root == NULL) return;

    calcolaSum(root, &sum);
    maxwt[root->val] = sum;

    for(i=0; i<k; i++)
      maxSum(root->figli[i], maxwt);

}

void calcolaSum(link root, float *sum){
   int i;

   if(root == NULL) return;

    *sum = *sum + root->peso;
    for(i=0; i<k; i++)
        calcolaSum(root->figli[i], sum);

}


void stampa(link root){
int i;
if(root==NULL) return;
printf("%d ", root->val);
    for(i=0; i<k; i++)
    stampa(root->figli[i]);

}

link newNode(int val, float peso, link f1, link f2, link f3){
link x = malloc(sizeof(*x));
x->val = val;
x-> peso = peso;
x->figli[0] = f1;
x->figli[1] = f2;
x->figli[2] = f3;
return x;
}


