#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void perm_sempl(int pos, int *val, int *sol, int *mark, int n, int *fin);
void verifica(int *sol, int n, int *fin);

int best_diff = INT_MAX;

int main()
{
    int n = 10, i;
    int val[10] = {-1, -6, 3, 14, -5, 16, 7, 8, -9, 120};
    int *sol = malloc(n*sizeof(int));
    int *mark = calloc(n, sizeof(int));
    int *fin = malloc(n*sizeof(int));


    perm_sempl(0,val,sol,mark,n, fin);
    printf("%d\n", best_diff);

    for(i=0; i<n; i++)
        printf("%d ", fin[i]);
    printf("\n");


    return 0;
}


void perm_sempl(int pos, int *val, int *sol, int *mark, int n, int *fin){
    int i;

if(pos>=n){
    verifica(sol, n, fin);
    return;
    }

    for(i=0; i<n; i++){
        if(mark[i]==0){
            mark[i]=1;
            sol[pos]=val[i];
            perm_sempl(pos+1,val, sol, mark, n, fin);
            mark[i]=0;
            }
        }
        return;
}

void verifica(int *sol, int n, int *fin){

int saldo_max=0, saldo_min= INT_MAX, diff, corr=0, i;

for(i=0; i<n;i++){
    corr+= sol[i];
    if(saldo_max<corr) saldo_max= corr;
    if(saldo_min>corr) saldo_min= corr;
    }
    diff = saldo_max-saldo_min;
    if(best_diff>diff){
        best_diff=diff;
        for(i=0; i<n; i++)
            fin[i]=sol[i];
    }
    return;
}
