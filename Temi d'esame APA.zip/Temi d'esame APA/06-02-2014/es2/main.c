#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node *link;

struct node {
    char *nome;
    char *cognome;
    link next;
};

typedef struct lista_t{
    link head;
}lista_t;

int inserisciInOrdine(lista_t *lista, char *cognome, char *nome);
link newNode (char *cognome, char *nome);

int main(){
    char cognome[20];
    char nome[20];
    int i;
    lista_t *lista;
    link t;

    lista = malloc(sizeof(*lista));
    lista->head = NULL;

    for(i=0; i<3; i++){
        printf("Inserisci cognome: ");
        scanf("%s", cognome);
        printf("Inserisci nome: ");
        scanf("%s", nome);

        printf("%d", inserisciInOrdine(lista, cognome, nome) );
    }

    for(t=lista->head; t!=NULL; t=t->next){
        printf("%s %s \n", t->cognome, t->nome);
    }

    return 0;
}

link newNode (char *cognome, char *nome){
    link x=malloc(sizeof(*x));

    x->cognome = strdup(cognome);
    x->nome = strdup(nome);
    x->next = NULL;
    return x;
}

int inserisciInOrdine(lista_t *lista, char *cognome, char *nome){
    link x,t,p;
    x=newNode(cognome, nome);

    t = lista->head;
    p = t;

    while(t!=NULL && (strcmp(t->cognome,cognome)<0 || (strcmp(t->cognome,cognome)==0 && strcmp(t->nome,nome)<=0))){
             if( strcmp(t->cognome,cognome)==0 && strcmp(t->nome, nome)==0 )
            return 0;
        p = t;
        t = t->next;
    }

    if(t==lista->head){ //primo in lista
        x->next = lista->head;
        lista->head = x;
        return 1;
    }

    p->next = x;
    x->next = t;
    return 1;

}
