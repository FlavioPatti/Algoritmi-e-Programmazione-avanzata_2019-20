#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int powerset_comb(int pos, int *sol, int n, int k, int start);
int verifica(int *sol, int n, int k);

int main()
{   int n = 3, k, trovato = 0;
    int *sol = malloc(2*n*sizeof(int));

    for (k=1; k <= 2*n && trovato==0; k++) {
    if(powerset_comb(0, sol, n, k, 0))
      trovato = 1;
  }

    return 0;
}
int verifica(int *sol, int n, int k){
    int i,j, z, scelta;
     int mat[3][3] = { {0,1,0}, {1,0,1}, {0,1,0} };

     for(z=0; z<k; z++){
        scelta = sol[z];

        if(scelta<n){
            for(j=0; j<n;j++){
                if(mat[scelta][j]==0) mat[scelta][j]=1;
                else mat[scelta][j] = 0;
            }
        }else{
            for(j=0; j<n; j++){
                if(mat[j][scelta-n]==0) mat[j][scelta-n]=1;
                else mat[j][scelta-n] = 0;
            }
        }
     }
     for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            if(mat[i][j]==0) return 0;
        }
     }
     return 1;
}
int powerset_comb(int pos, int *sol, int n, int k, int start) {

  int i;
  if (pos >= k) {
    if (verifica(sol,n,k)) {
      for (i=0; i < k; i++)
        printf("%d ", sol[i]);
      printf("\n");
      return 1;
    }
    return 0;
  }

  for (i = start; i < 2*n; i++) {
    sol[pos] = i;
    if (powerset_comb(pos+1, sol, n, k, i+1))
      return 1;
  }
  return 0;
}
