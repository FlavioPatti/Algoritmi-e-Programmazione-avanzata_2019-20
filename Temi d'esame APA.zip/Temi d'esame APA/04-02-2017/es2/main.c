#include <stdio.h>
#include <stdlib.h>
typedef struct node* link;
struct node{
int val;
link sx;
link dx;
};
link newNode(int val, link sx, link dx);
link mirror(link root);
void printTree(link root);

int main()
{   link x;
    link i = newNode(4,NULL,NULL);
    link h = newNode(2,NULL,NULL);
    link e = newNode(7,NULL,NULL);
    link f = newNode(17,NULL,NULL);
    link g = newNode(20,NULL,NULL);
    link d = newNode(3,h,i);
    link c = newNode(18,f,g);
    link b = newNode(6,d,e);
    link a = newNode(15,b,c);

    printTree(a);
    x = mirror(a);
    printf("\n");
    printTree(x);

    return 0;
}
link mirror(link root){
    if(root == NULL) return NULL;

        link x = newNode(root->val,NULL,NULL);

        x->sx = mirror(root->dx);
        x->dx = mirror(root->sx);

    return x;
}

void printTree(link root){
    if(root == NULL) return;
printf("%d ", root->val);
printTree(root->sx);
printTree(root->dx);
}
link newNode(int val, link sx, link dx){
link x = malloc(sizeof(*x));
x->val = val;
x->sx = sx;
x->dx = dx;
return x;
}
