#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

void disp_rip(int num_moli, int lunghezza_moli, int num_navi, int*navi, int *sol, int *best_sol, int pos);
int verifica(int num_moli, int lunghezza_moli, int num_navi, int *navi, int *sol, int *best_sol);

int minimo = INT_MAX;

int main()
{
    int num_moli = 3;
    int lunghezza_moli = 10;
    int num_navi = 7;
    int navi[7] = {8,3,5,2,5,2,9};
    int *sol = malloc(num_navi*sizeof(int));
    int *best_sol = malloc(num_navi*sizeof(int));
    int i;

    disp_rip(num_moli,lunghezza_moli,num_navi,navi, sol, best_sol, 0);

    for(i=0; i<num_navi; i++) printf("%d ", best_sol[i]);
    printf("\n");

    return 0;
}

int verifica(int num_moli, int lunghezza_moli, int num_navi, int *navi, int *sol, int* best_sol){
    int i, sum = 0;
    int *mark = calloc(2*num_moli,sizeof(int));
    int *mark2 = calloc(num_moli, sizeof(int));

    for(i=0; i<num_navi; i++){
        mark[sol[i]]+= navi[i];
    }

    for(i=0; i<2*num_moli; i++){
        if(mark[i]>lunghezza_moli)
            return 0;
    }
    for(i=0; i<2*num_moli; i++){
        if(mark[i]==0 || mark[i]==1) mark2[0] = 1;
        if(mark[i]==2 || mark[i]==3) mark2[1] = 1;
        if(mark[i]==4 || mark[i]==5) mark2[2] = 1;
    }
    for(i=0; i<num_moli; i++)
        if(mark2[i]==1)
        sum++;

    if(sum<minimo){
        minimo = sum;
        for(i=0; i<num_navi; i++) best_sol[i]=sol[i];
        return 1;
    }

return 0;

}

void disp_rip(int num_moli, int lunghezza_moli, int num_navi, int*navi, int *sol, int *best_sol,int pos){
int i;
if(pos>=num_navi){
    verifica(num_moli,lunghezza_moli, num_navi, navi, sol, best_sol);
    return;
}

for(i=0; i<2*num_moli; i++){
    sol[pos]=i;
    disp_rip(num_moli,lunghezza_moli,num_navi, navi, sol,best_sol, pos+1);
    }
}
