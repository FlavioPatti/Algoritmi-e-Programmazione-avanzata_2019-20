#include <stdio.h>
#include <stdlib.h>
typedef struct node* link;
struct node{
int val;
link sx;
link dx;
};

link newNode(int val, link sx, link dx);
int subtree(link root1, link root2);
int subtreeR(link root1, link root2);

int main()
{   link g = newNode(9,NULL,NULL);
    link f = newNode(0,NULL,NULL);
    link e = newNode(2,g,NULL);
    link d = newNode(2,NULL,NULL);
    link c = newNode(1,NULL,f);
    link b = newNode(7,d,e);
    link root1 = newNode(3,b,c);

    link m = newNode(9,NULL,NULL);
    link l = newNode(2,m,NULL);
    link i = newNode(2,NULL,NULL);
    link root2 = newNode(7,i,l);

    link p = newNode(1, NULL, NULL);
    link o = newNode(4, NULL, NULL);
    link root3 = newNode(3,o,p);
    link root4 = newNode(4,NULL,NULL);

    printf("%d ", subtree(root1,root2));
    printf("%d ", subtree(root1, root3));
    printf("%d ", subtree(root1, root4));
    printf("%d ", subtree(root3,root4));

    return 0;
}

int subtree(link root1, link root2){
if(root1 == NULL) return 0;

if(root1->val == root2->val){
    return subtreeR(root1,root2);
}

return subtree(root1->sx, root2) || subtree(root1->dx, root2);
}

int subtreeR(link root1, link root2){
    if (root2 == NULL && root1 !=NULL) return 0;
    if (root1 == NULL && root2 != NULL) return 0;
    if(root1 == NULL && root2 == NULL) return 1;

if(root1->val == root2->val){
    return subtreeR(root1->sx, root2->sx) && subtreeR(root1->dx, root2->dx);
}

return 0;
}

link newNode(int val, link sx, link dx){
link x = malloc(sizeof(*x));
x->val = val;
x->sx = sx;
x->dx = dx;
return x;
}
