#include <stdio.h>
#include <stdlib.h>

int minimo = 4;
int disp_rip(int *sale, int num_sale, int* prenotazioni, int num_prenotazioni, int *sol, int *best_sol, int pos);
void solve(int *S, int nS, int *P, int nP);

int main() {

	int sale[] = { 4, 9, 11, 5 };
	int	prenotazioni[] = { 2, 2, 3, 2, 6, 2};
	int num_sale = 4;
	int	num_prenotazioni = 6;


    solve(sale,num_sale,prenotazioni,num_prenotazioni);


	return 0;
}

void solve(int *S, int nS, int *P, int nP){
int i;
int *sol = malloc(nP*sizeof(int));
int *best_sol = malloc(nP*sizeof(int));

if(disp_rip(S,nS,P,nP,sol,best_sol,0)){
        printf("soluzione trovata:\n");
for(i=0; i<nP; i++) printf("%d", best_sol[i]);
}
else printf("soluzione non trovata");

}

int verifica(int *sale, int num_sale, int *prenotazioni, int num_prenotazioni, int *sol, int *best_sol){
    int i, sum = 0;
    int *mark = calloc(num_sale,sizeof(int));

    for(i=0; i<num_prenotazioni; i++){
        mark[sol[i]] += prenotazioni[i];
    }

    for(i=0; i<num_prenotazioni; i++){
        if(mark[i]>sale[i]) return 0;
    }
    for(i=0; i<num_sale; i++){
        if(mark[i]>0) sum++;
    }
    if(sum<=minimo){
        minimo = sum;
    for(i=0; i<num_prenotazioni; i++)
        best_sol[i]=sol[i];

    return 1;
    }

    return 0;
}

int disp_rip(int *sale, int num_sale, int* prenotazioni, int num_prenotazioni, int *sol, int *best_sol,int pos){
int i;

if(pos>=num_prenotazioni){
        if(verifica(sale,num_sale,prenotazioni,num_prenotazioni,sol, best_sol)){
        return 1;
        }
    return 0;
}

for(i=0; i<num_sale; i++){
    sol[pos]=i;
    if(disp_rip(sale,num_sale,prenotazioni,num_prenotazioni,sol,best_sol,pos+1)) return 1;
}
return 0;
}
