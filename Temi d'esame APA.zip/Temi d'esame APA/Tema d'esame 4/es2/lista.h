#ifndef LISTA_H
#define LISTA_H
#include "nodo.h"

typedef struct lista_s{
link head;
}lista_t;


void stampa(lista_t L);
void LISTinsert(lista_t L, int val, int posizione);

#endif
