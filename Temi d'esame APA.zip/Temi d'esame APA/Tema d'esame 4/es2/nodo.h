#ifndef NODO_H
#define NODO_H

typedef struct node* link;

struct node{
int val;
int cnt;
int pos;
link next;
};

link newNode(int val, int cnt, int pos, link next);

#endif
