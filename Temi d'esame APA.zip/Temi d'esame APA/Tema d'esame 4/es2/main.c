#include <stdio.h>
#include <stdlib.h>
#include "lista.h"

int main()
{
        link a = newNode(5,0,0,NULL);
        a->next = a;
        lista_t L;
        L.head = a;

        LISTinsert(L,5,0);
        stampa(L);

    return 0;
}
