#include <stdio.h>
#include <stdlib.h>
#include "nodo.h"

link newNode(int val, int cnt, int pos, link next){
link x = malloc(sizeof(*x));
x->val = val;
x->cnt = cnt+1;
x->pos = pos;
x->next = next;
return x;
}
