#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
#include "nodo.h"


void LISTinsert(lista_t L, int val, int posizione){
link t = L.head;
int trovato = 0;

    do{
    if(t->val == val){
        t->cnt++;
        trovato = 1;
        break;
    }
    t = t->next;
    }while(t!=L.head);

    if(trovato==0){
        t = L.head;
    link x = newNode(val,0,posizione,NULL);
    if(t->next == t){
    x->next = t;
    t->next = x;
    }
    else {
    while(t->next->pos < posizione && t->next!=L.head){
    t = t->next;
    }
    if(t->next->pos>posizione){
        x->next = t->next;
        t->next = x;
    }
    if(t->next==L.head){
    t->next = x;
    x->next = L.head;
    }

        }
    }
}

void stampa(lista_t L){
link t = L.head;
do{
    printf("Valore: %d, occorrenze: %d\n", t->val, t->cnt);
    t = t->next;
}while(t!=L.head);
printf("\n");
}



