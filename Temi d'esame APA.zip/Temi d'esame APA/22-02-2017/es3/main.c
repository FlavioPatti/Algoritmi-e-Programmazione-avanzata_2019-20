#include <stdio.h>
#include <stdlib.h>

typedef struct coppia_s{
int n1;
int n2;
}coppia_t;

int *f(int n, int k, int m[n][n]);
void comb_sempl(coppia_t* coppie, int *sol, int val[], int n, int k, int pos, int start);
void powerset(coppia_t *coppie, int mat[][4], int *sol, int n, int k, int pos);
int verifica(coppia_t *coppie, int mat[][4], int *sol);
int dim = 0;

int main()
{
    int mat[4][4] = { {0,0,1,0}, {0,0,0,1}, {1,0,0,1}, {0,1,1,0} };
    int k = 2;
    int n = 4;

    f(n,k,mat);

    return 0;
}

int *f(int n, int k, int m[n][n]){
//genero tutte le soluzioni
int i;
coppia_t* coppie = malloc(6*sizeof(coppia_t));
int val[4] = {0,1,2,3};
int *sol = malloc(k*sizeof(int));
comb_sempl(coppie,sol,val,n,k,0,0);

for(i=0; i<dim; i++) printf("%d%d\n", coppie[i].n1, coppie[i].n2);

sol = realloc(sol, dim*sizeof(int));
powerset(coppie,m,sol,n,k,0);

    return 0;
}

int verifica(coppia_t *coppie, int mat[][4], int *sol){
int i, n1, n2, insep = 0;

    for(i=0; i<dim; i++){
        if(sol[i]==1){
            n1 =  coppie[i].n1;
            n2 = coppie[i].n2;
            if(mat[n1][n2]!=0) return 0;
            else insep++;
        }
    }
    if(insep!=3) return 0;
    return 1;

}
void powerset(coppia_t *coppie, int mat[][4], int *sol, int n, int k, int pos){
int i=0;
if(pos>=dim){
    if( verifica(coppie, mat, sol) ){
        for(i=0; i<dim; i++)
            printf("%d ", sol[i]);
        printf("\n");
    }
    return;
}

sol[pos] = 0; //primo gruppo di coppie non prese
powerset(coppie,mat,sol,n,k,pos+1);
sol[pos] = 1; //secondo gruppo di coppie prese
powerset(coppie,mat,sol,n,k,pos+1);
}

void comb_sempl(coppia_t* coppie, int *sol, int val[], int n, int k, int pos, int start){
int i;
if(pos>=k){
        coppie[dim].n1 = sol[0];
        coppie[dim].n2 = sol[1];
        dim++;
        return;
}
for(i = start; i<n; i++){
    sol[pos] = val[i];
    comb_sempl(coppie, sol, val, n, k, pos+1, i+1);
    }
}
