#include <stdio.h>
#include <stdlib.h>

typedef struct node* link;

struct node{
int val;
int num_figli;
link padre;
link figlio;
link fratm;
};
void stampaAlbero(link a);
link newNode(int val, int num_figli, link padre, link figlio, link fratm);
void processTree(link root);

int main()
{
    link j = newNode(10,0,NULL,NULL,NULL);
    link i = newNode(9,0,NULL,NULL,j);
    link h = newNode(8,0,NULL,NULL,i);
    link e = newNode(7,0,NULL,h,NULL);
    link g = newNode(6,0,NULL,NULL,NULL);
    link f = newNode(5,0,NULL,NULL,g);
    link d = newNode(4,0,NULL,f,NULL);
    link c = newNode(3,0,NULL,NULL,d);
    link b = newNode(2,0,NULL,e,c);
    link a = newNode(1,0,NULL,b,NULL);

  //  stampaAlbero(a);
    processTree(a);
    printf("\n%d %d %d\n", a->figlio->padre->val, a->figlio->fratm->padre->val, a->figlio->fratm->fratm->padre->val);
    link x = d;
    printf("%d %d\n", d->figlio->padre->val, d->figlio->fratm->padre->val);
    link y = e;
    printf("%d %d %d\n", e->figlio->padre->val, e->figlio->fratm->padre->val, e->figlio->fratm->fratm->padre->val);

    return 0;
}

void stampaAlbero(link a){
    if(a==NULL) return;
printf("%d ", a->val);
stampaAlbero(a->figlio);
stampaAlbero(a->fratm);
}
void processTree(link root){
link x;
if(root == NULL) return;

if(root->figlio!=NULL){
    root->num_figli++;
    x = root->figlio;
    x->padre = root;
    while(x->fratm!=NULL){
        root->num_figli++;
        x->fratm->padre = root;
        x = x->fratm;
        }
}
printf("%d ", root->num_figli);
processTree(root->figlio);
processTree(root->fratm);

}

link newNode(int val, int num_figli, link padre, link figlio, link fratm){
link x = malloc(sizeof(*x));
x->val = val;
x->num_figli = num_figli;
x->padre = padre;
x->figlio = figlio;
x->fratm = fratm;
return x;
}
