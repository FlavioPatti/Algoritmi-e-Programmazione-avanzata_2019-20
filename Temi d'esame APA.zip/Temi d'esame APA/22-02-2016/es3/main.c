#include<stdlib.h>
#include<string.h>
#include<stdio.h>

int verifica(int **inter, int m, int k, int *sol) {
  int i, j, ok = 1, *lampadine;
  lampadine = calloc(m, sizeof(int));

  for(j=0; j<m && ok; j++) {
    for (i=0; i<k; i++)
      lampadine[j] += inter[sol[i]][j];
    if (lampadine[j]%2 ==0)
      ok = 0;
  }
  return ok;
}

int powerset_comb(int pos, int *sol, int n, int k, int start, int **inter,  int m) {

  int i;
  if (pos >= k) {
    if (verifica(inter, m, k, sol)) {
      for (i=0; i < k; i++)
        printf("%d ", sol[i]);
      printf("\n");
      return 1;
    }
    return 0;
  }

  for (i = start; i < n; i++) {
    sol[pos] = i;
    if (powerset_comb(pos+1, sol, n, k, i+1, inter, m))
      return 1;
  }
  return 0;
}

int main(void) {
  int n=4, m=5, k, i,j, trovato=0, *sol, **inter;
  inter = malloc(n*sizeof(int *));
  for(i=0;i<4; i++) inter[i]=malloc(m*sizeof(int));
  inter[0][0] = 1;
  inter[0][1] = 1;
  inter[0][2] = 0;
  inter[0][3] = 0;
  inter[0][4] = 1;
  inter[1][0] = 1;
  inter[1][1] = 0;
  inter[1][2] = 1;
  inter[1][3] = 0;
  inter[1][4] = 0;
  inter[2][0] = 0;
  inter[2][1] = 1;
  inter[2][2] = 1;
  inter[2][3] = 1;
  inter[2][4] = 0;
  inter[3][0] = 1;
  inter[3][1] = 0;
  inter[3][2] = 0;
  inter[3][3] = 1;
  inter[3][4] = 0;
   for(i=0; i<n; i++){
    for(j=0; j<m; j++) printf("%d ", inter[i][j]);
    printf("\n");
   }

  sol = calloc(n, sizeof(int));

  for (k=1; k <= n && trovato==0; k++) {
    if(powerset_comb(0, sol, n, k, 0, inter, m))
      trovato = 1;
  }
  return 0;
}

