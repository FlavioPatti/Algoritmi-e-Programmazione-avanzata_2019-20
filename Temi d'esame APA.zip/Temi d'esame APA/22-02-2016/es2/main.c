#include <stdio.h>
#include <stdlib.h>

typedef struct node* link;
struct node{
int val;
link next;
};

typedef struct lista_s{
link head;
}lista_t;

link newNode(int val, link next);
void stampaLista(lista_t *L);
lista_t *split_list(int n, lista_t *L0, lista_t **L2);

int main()
{
    int n = 5;
    lista_t *L0 = malloc(sizeof(*L0));
    lista_t *L1 = malloc(sizeof(*L1));
    lista_t *L2 = malloc(sizeof(*L2));
    L0->head = NULL;
    L1->head = NULL;
    L2->head = NULL;
    link a = newNode(1,NULL);
    link b = newNode(10, a);
    link c = newNode(6, b);
    link d = newNode(7, c);
    link e = newNode(5, d);
    link f = newNode(3, e);
    L0->head = f;

    stampaLista(L0);

    L1 = split_list(n, L0, &L2);

    stampaLista(L1);
    stampaLista(L2);

    return 0;
}

lista_t *split_list(int n, lista_t *L0, lista_t **L2){
link h = L0->head, t;
lista_t *rev = malloc(sizeof(*rev));
lista_t *L1 = malloc(sizeof(*L1));
rev->head = NULL;
L1->head = NULL;

while(h!=NULL){ //inverto L0
    t = newNode(h->val, rev->head);
    rev->head = t;
    h = h->next;
}
stampaLista(rev);

for(h = rev->head; h!=NULL; h = h->next){
    if(h->val < n){
        t = newNode(h->val, L1->head);
        L1->head = t;
    }else{
        t = newNode(h->val, (*L2)->head);
        (*L2)->head = t;
    }
}
return L1;
}

void stampaLista(lista_t *L){
link h;
for(h = L->head; h!=NULL; h = h->next)
    printf("%d ", h->val);
    printf("\n");
}

link newNode(int val, link next){
link x = malloc(sizeof(x));
x->val = val;
x->next = next;
return x;
}
