#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node *link;
struct node{
char *piatto;
link next;
};

typedef struct lista_s{
link head;
}lista_t;

typedef struct data_s{
lista_t *scelte;
int n;
}data_t;

void build_menu(data_t *data);
data_t *aggiungiPiatto(data_t *data, char * nomePortata, int pos);
void stampaPortate(data_t *data);
void princ_molt(data_t *data, char **sol, int pos);

int main()
{
    int i;
    data_t *data = malloc(sizeof(*data));
    data->n = 3;
    data->scelte = malloc(data->n*sizeof(lista_t));
    for(i=0; i<data->n; i++){
        data->scelte[i].head = NULL;
    }

    data = aggiungiPiatto(data, "riso", 0);
    data = aggiungiPiatto(data, "pasta", 0);

    data = aggiungiPiatto(data, "formaggio", 1);
    data = aggiungiPiatto(data, "pesce", 1);
    data = aggiungiPiatto(data, "carne", 1);

    data = aggiungiPiatto(data, "torta", 2);
    data = aggiungiPiatto(data, "gelato", 2);

    printf("la lista delle portate e':\n");
    stampaPortate(data);

    build_menu(data);

    return 0;
}
void stampaPortate(data_t *data){
int i;
link x;
for(i=0; i< data->n; i++){
       x=data->scelte[i].head;
    while(x!=NULL){
        printf("%s ", x->piatto);
        x = x->next;
    }
    printf("\n");
    }
}

data_t *aggiungiPiatto(data_t *data, char * nomePortata, int pos){
    link x = malloc(sizeof(*x));
    x->piatto = strdup(nomePortata);
    x->next = data->scelte[pos].head;
    data->scelte[pos].head = x;
    return data;
}

void build_menu(data_t *data){
    int i;
    char **sol = malloc(data->n*sizeof(char *));
    for(i=0; i<data->n; i++)
        sol[i]= malloc(10*sizeof(char));
    princ_molt(data,sol,0);
}

void princ_molt(data_t *data, char **sol, int pos){
link x;
if(pos>=data->n){
    printf("(%s, %s, %s)\n", sol[0], sol[1], sol[2]);
    return;
}

   x=data->scelte[pos].head;
    while(x!=NULL){
        sol[pos] = x->piatto;
        princ_molt(data, sol, pos+1);
        x = x->next;
    }

return;
}
