#include <stdio.h>
#include <stdlib.h>

typedef struct node* link;
struct node{
int val;
link next;
};
typedef struct list_s{
link head;
}list_t;

int aggiungi(link head);
void stampaLista(list_t * lista);
link newNode(int val, link next);

int n = 0;

int main()
{
    list_t* lista = malloc(sizeof(*lista));
    link c = newNode(10,NULL);
    link b = newNode(7,c);
    link a = newNode(4,b);
    lista->head = a;

    stampaLista(lista);
    printf("\n");
    printf("Nodi aggiunti: %d\n", aggiungi(lista->head) );
    stampaLista(lista);

    return 0;
}
int aggiungi(link head){
int start = head->val +1;
int stop;
link t;
link p;
link x, z;
for(z=head; z!=NULL; z= z->next) stop = z->val;

while(start != stop){
        t = head;
        p = t;
while(t!=NULL && t->val<start){
    p=t;
    t=t->next;
}
if(t->val > start){
x = newNode(start,NULL);
p->next = x;
x->next = t;
start++;
n++;
}else{ start++; };

}


return n;
}


void stampaLista(list_t * lista){
    link x;
    for(x = lista->head; x!=NULL; x = x->next) printf("%d ", x->val);
    printf("\n");
}

link newNode(int val, link next){
link x = malloc(sizeof(*x));
x->val = val;
x->next = next;
return x;
}
