#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node2_s{
char nome_prodotto[20];
struct node2_s *prox_prod;
}node2_t;

typedef struct node1_s{
char nome_agricoltore[20];
struct node1_s *prox_agri;
node2_t* head;
}node1_t;

void visitList(node1_t* head1);
node1_t* newAgri(char nome_agricoltore[], node1_t* prox_agri, node2_t* head);
node2_t* newProd(char nome_prodotto[], node2_t* prox_prod);
node1_t *list_of_list_invert(node1_t *head1);

int main()
{
    node2_t* c = newProd("product2", NULL);
    node2_t* b = newProd("product4", c);
    node2_t* a = newProd("product5", b);
    node2_t* h = newProd("product2", NULL);
    node2_t* g = newProd("product5", h);
    node2_t* f = newProd("product3", NULL);
    node2_t* e = newProd("product4", f);
    node2_t* d = newProd("product2", e);

    node1_t* C = newAgri("farmer3", NULL, g);
    node1_t* B = newAgri("farmer2", C, d);
    node1_t* A = newAgri("farmer1", B, a);

    node1_t* head1 = A;
    node1_t* head2 = NULL;

    visitList(head1);

    head2 = list_of_list_invert(head1);
    visitList(head2);


    return 0;
}
node1_t *list_of_list_invert(node1_t *head1){
    node2_t* x;
    node2_t* t;
    node1_t* head2 = NULL;
    node1_t* y;
    node1_t* z;
    node1_t* p;
    char nome[20];
    int flag = 0;

    //creo la lista
    z = head1;
    while(z!=NULL){
    for(x = z->head; x!=NULL; x= x->prox_prod){
        flag = 0;
        strcpy(nome,x->nome_prodotto);
        if(head2==NULL){
            p = newAgri(nome,NULL,NULL);
            head2 = p;
        }else{
            for(y = head2; y!=NULL; y= y->prox_agri){
                if(strcmp(y->nome_agricoltore,nome)==0) flag = 1;
            }
            if(flag==0){
                p = newAgri(nome,head2,NULL);
                head2 = p;
                }
            }
        }
        z = z->prox_agri;
    }
    //creo la lista di liste
    z = head2;
    while(z!=NULL){
        strcpy(nome,z->nome_agricoltore);
        y = head1;
        while(y!=NULL){
        for(x = y->head; x!=NULL; x= x->prox_prod){
            if(strcmp(nome, x->nome_prodotto)==0){
                t = newProd(y->nome_agricoltore, z->head);
                z->head = t;
                }
            }
            y = y->prox_agri;
        }
        z = z->prox_agri;
    }

    return head2;

}

void visitList(node1_t* head1){
    node2_t* x;
        if(head1 == NULL) return;
printf("%s: ", head1->nome_agricoltore);
for(x=head1->head; x!=NULL; x = x->prox_prod) printf("%s ", x->nome_prodotto);
printf("\n");
visitList(head1->prox_agri);
}

node2_t* newProd(char nome_prodotto[], node2_t* prox_prod){
node2_t* x = malloc(sizeof(*x));
strcpy(x->nome_prodotto, nome_prodotto);
x->prox_prod = prox_prod;
return x;
}
node1_t* newAgri(char nome_agricoltore[], node1_t* prox_agri, node2_t* head){
node1_t* x = malloc(sizeof(*x));
strcpy(x->nome_agricoltore, nome_agricoltore);
x->prox_agri = prox_agri;
x->head = head;
return x;
}
