#include <stdio.h>
#include <stdlib.h>

int powerset(int pos, int* sol, int p, int k, int val[], int start);
int verifica(int *sol, int p, int k, int val[]);

int main()
{
    int val[5] = {2,2,3,2,1};
    int p = 5, k, trovato = 0;
    int *sol;

    for(k=1; k<=p-1 && trovato == 0; k++){
        sol = calloc(k,sizeof(int));
        printf("cardinalita %d\n", k);
        if(powerset(0,sol,p,k,val, 0))
            trovato = 1;
    }

    return 0;
}

int verifica(int *sol, int p, int k, int val[]){
    int i;

    if(sol[0]!=0) return 0;

    for(i=0; i<k-1; i++){
        if(sol[i]+val[sol[i]]<sol[i+1]) return 0;
    }

    if(sol[k-1]+val[sol[k-1]]>=p-1) return 1;
    return 0;
}

int powerset(int pos, int* sol, int p, int k, int val[], int start){
int i;

if(pos>=k){
    if(verifica(sol,p,k,val)){
        for(i = 0; i<k; i++) printf("%d ", sol[i]);
        printf("\n");
       return 1;
    }
    return 0;
}

for(i=start; i<p-1; i++){
    sol[pos] = i;
    if(powerset(pos+1,sol,p,k,val,i+1))
        return 1;
}
return 0;
}
