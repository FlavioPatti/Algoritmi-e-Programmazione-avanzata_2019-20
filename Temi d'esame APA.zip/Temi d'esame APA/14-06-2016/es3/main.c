#include <stdio.h>
#include <stdlib.h>
#define N 5

void cover(int S[][9], int n, int k);
void powerset(int S[][9], int *sol, int *mark, int n, int k, int pos);
int controlla(int S[][9],int *sol,int *mark,int n,int k);

int main()
{  int S[N][9]={ {1,2,3,0,0,0,0,0,0},
                 {2,3,7,0,0,0,0,0,0},
                 {7,8,0,0,0,0,0,0,0},
                 {3,4,0,0,0,0,0,0,0},
                 {4,5,6,0,0,0,0,0,0} };

    cover(S,N,3);

    return 0;
}

void cover(int S[][9], int n, int k){

int *sol = malloc(n*sizeof(int));
int *mark = calloc(8,sizeof(int));

powerset(S, sol, mark, n, k, 0);
}

void powerset(int S[][9], int *sol, int *mark, int n, int k, int pos){
int i;
if(pos>=n){
    if(controlla(S,sol,mark,n,k)){
        printf("soluzione trovata\n");
      for(i=0; i<n; i++) printf("%d ", sol[i]);
    }
    return;
}

sol[pos]=0;
powerset(S,sol,mark,n,k,pos+1);
sol[pos]=1;
powerset(S,sol,mark,n,k,pos+1);
}

int controlla(int S[][9],int *sol,int *mark,int n,int k){
int i,j, count = 0;
mark = calloc(8,sizeof(int));

for(i=0; i<n; i++){
    if(sol[i]==1) count++;
}
if(count == 3){

for(i=0; i<n; i++){
    if(sol[i]==1){
        for(j=0; j<9;j++){
            if(S[i][j]!=0){
                mark[S[i][j]-1]=1;
                }
            }
        }
    }

for(i=0; i<8;i++){
    if(mark[i]!=1)
        return 0;
        }
return 1;
}else
return 0;

}
