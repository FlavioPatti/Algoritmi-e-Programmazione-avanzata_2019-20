#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int separaParole(char frase[1000], char ***parole);

int main()
{
char frase[1000]= { "Ciao come stai? Tutto bene?" }, **parole;
int n, i;

n = separaParole(frase,&parole);

for (i=0; i<n; i++)
 printf("parola %d -> %s\n", i,parole[i]);

    return 0;
}

int separaParole(char frase[1000], char ***parole){
int i,j,k, n_par = 0;
char *tmp = malloc(20*sizeof(char));

for(i=0; i<strlen(frase);i++){
    if(frase[i]==' ')
        n_par ++;
}
n_par++;

(*parole) = malloc(n_par* sizeof(char *));


i=0;
k=0;
while(frase[i]!='\0'){
    j=0;
  while(frase[i]!=' ' && frase[i]!='\0'){
    tmp[j]=frase[i];
    i++;
    j++;
  }
    tmp[j]='\0';

    (*parole)[k]= strdup(tmp);
    k++;
    i++;
}

return n_par;
}
