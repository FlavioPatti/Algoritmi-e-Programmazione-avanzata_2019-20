#include <stdio.h>
#include <stdlib.h>

void matMax (int **m, int r, int c);

int main()
{
    int **m;
    int r=3, c=4, i, j;

    m= malloc(3*sizeof(int *));
    for(i=0; i<c; i++) m[i]=malloc(c* sizeof(int));

    m[0][0]=5;
    m[0][1]=2;
    m[0][2]=3;
    m[0][3]=1;
    m[1][0]=4;
    m[1][1]=1;
    m[1][2]=6;
    m[1][3]=4;
    m[2][0]=3;
    m[2][1]=0;
    m[2][2]=5;
    m[2][3]=2;

    for(i=0; i<r; i++){
        for(j=0; j<c; j++){
            printf("%d ", m[i][j]);
        }
        printf("\n");
    }

    matMax(m,r,c);


    return 0;
}

void matMax (int **m, int r, int c){
    int dx[8], dy[8], newx, newy;
    int i, j, k, trovato = 1;

  dx[0] =  0; dy[0] =  1;   //basso
  dx[1] =  0; dy[1] =  -1; //alto
  dx[2] = 1; dy[2] =  0; //destra
  dx[3] = -1; dy[3] =  0; //sinistra
  dx[4] = -1; dy[4] = -1; //sx-alto
  dx[5] = 1; dy[5] = -1; //dx-alto
  dx[6] =  -1; dy[6] = 1; //sx-basso
  dx[7] =  1; dy[7] = 1; //dx-basso

  for(i=0; i<r; i++){
    for(j=0; j<c; j++){
            trovato = 1;
        for(k=0; k<8; k++){
        newx = i + dx[k];
        newy = j + dy[k];
    if ((newx<c) && (newx>=0) && (newy<r) && (newy>=0)){
            if(m[i][j] <= m[newx][newy])
                trovato = 0;
            }
        }
        if(trovato == 1) printf("(%d %d)\n", i, j);
    }
  }

}
