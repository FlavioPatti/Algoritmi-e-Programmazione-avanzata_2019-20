#include <stdio.h>
#include <stdlib.h>
typedef struct node1* link1;
typedef struct node2* link2;
struct node1{
int val;
link1 next;
};
struct node2{
int val;
int occ;
link2 next;
};

link2 comprimi(link1 head);
void stampa(link2 A);
link1 newNode1(int val, link1 next);
link2 newNode2(int val, int occ, link2 next);

int main()
{
    link1 l = newNode1(5,NULL);
    link1 i = newNode1(5, l);
    link1 h = newNode1(5, i);
    link1 g = newNode1(3,h);
    link1 f = newNode1(2,g);
    link1 e = newNode1(2,f);
    link1 d = newNode1(3,e);
    link1 c = newNode1(3,d);
    link1 b = newNode1(3,c);
    link1 a = newNode1(3,b);

    link2 A = comprimi(a);
    stampa(A);

    return 0;
}
void stampa(link2 A){
    link2 x;
for(x = A; x!=NULL; x= x->next) printf("%d %d\n", x->val, x->occ);
}
link2 comprimi(link1 head){
    link1 x = head;
    link2 h = NULL;
    int tmp, occ = 0;
    while(x!=NULL){
        tmp = x->val;
        h = newNode2(tmp,0,h);
        occ = 0;
        while(x->val==tmp){
        occ++;
        x = x->next;
        if(x==NULL) break;
        }
        h->occ = occ;
    }
    return h;
}
link2 newNode2(int val, int occ, link2 next){
link2 x = malloc(sizeof(*x));
x->val = val;
x->occ = occ;
x->next = next;
return x;
}

link1 newNode1(int val, link1 next){
link1 x = malloc(sizeof(*x));
x->val = val;
x->next = next;
return x;
}
