#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef struct pasticcini_s{
int codice;
int peso;
int quantita;
}pasticcini_t;
void permutazioni_rip(pasticcini_t *paste,int n_dist,int* mark, int *sol, int *best_sol, int vassoio, int pos, int sum, int tot);
void check(int sum, int vassoio, int *sol,int *best_sol, int tot);
int escursione_minima = INT_MAX;
int totale_pasticcini = 0;
int main()
{
    pasticcini_t paste[3];
    paste[0].codice = 0;
    paste[1].codice = 1;
    paste[2].codice = 2;
    paste[0].peso = 25;
    paste[1].peso = 10;
    paste[2].peso = 3;
    paste[0].quantita = 3;
    paste[1].quantita = 2;
    paste[2].quantita = 7;
    int vassoio = 30;
    int *mark = malloc(3*sizeof(int));
    mark[0]=3;
    mark[1]=2;
    mark[2]=5;
    int *sol = malloc(5*sizeof(int));
    int *best_sol = malloc(5*sizeof(int));
    int i;

    permutazioni_rip(paste,3,mark,sol,best_sol,vassoio,0,0,0);

    for(i=0; i<totale_pasticcini; i++) printf("%d ", best_sol[i]);

    return 0;
}

void permutazioni_rip(pasticcini_t *paste,int n_dist,int* mark, int *sol,int *best_sol, int vassoio, int pos, int sum, int tot){
    int i;

    if(sum<=vassoio && sum!=0){
        check(sum,vassoio,sol,best_sol,tot);
    }

     for(i=0; i<n_dist; i++){
        if(mark[i]>0){
            mark[i]--;
            sol[pos]=paste[i].codice;
            sum += paste[i].peso;
            tot += 1;
            permutazioni_rip(paste, n_dist,mark,sol,best_sol,vassoio,pos+1, sum,tot);
            mark[i]++;
            sum -= paste[i].peso;
            tot -= 1;
        }
    }
}
void check(int sum, int vassoio, int *sol,int *best_sol, int tot){
    int diff, i;
            diff = vassoio-sum;
            if(diff<escursione_minima){
                escursione_minima = diff;
                totale_pasticcini = tot;
                for(i=0; i<tot; i++) best_sol[i] = sol[i];
            }
}
