#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

int maxSubSeq(int *X, int N, int *Y);
void powerset(int *x, int n, int *sol,int *y, int pos);
int verifica(int *x, int n, int *sol, int *y);
int max = 0;
int main()
{
    int X[16] = {0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15};
    int N = 16;
    int *Y = calloc(N,sizeof(int));

    int k = maxSubSeq(X,N,Y);
    printf("%d ", k);

    return 0;
}

int maxSubSeq(int *x, int n, int *y){
int *sol = malloc(n*sizeof(int));

powerset(x,n,sol,y,0);

for(int i=0; i<max; i++) printf("%d ", y[i]);
printf("\n");
return max;
}

int verifica(int *x, int n, int *sol, int *y){
int i, j=0;
int *indici = calloc(n,sizeof(int));
for(i=0; i<n; i++){
    if(sol[i]==1) indici[j++]=i;
}

for(i=0; i<j-1; i++){
    if(x[indici[i]]>=x[indici[i+1]]) return 0;
}

if(j>max){
    max = j;
    y = realloc(y,j*sizeof(int));
    for(i=0; i<j; i++) y[i]=x[indici[i]];
        return 1;
    }
    return 0;
}

void powerset(int *x, int n, int *sol,int *y, int pos){
if(pos>=n){
    verifica(x,n,sol,y);
    return;
}
sol[pos]=0;
powerset(x,n,sol,y,pos+1);
sol[pos] = 1;
powerset(x,n,sol,y,pos+1);

}


