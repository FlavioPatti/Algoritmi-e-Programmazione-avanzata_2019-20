#include <stdio.h>
#include <stdlib.h>

typedef struct node *link;
struct node{
int val;
link left;
link right;
};

link newNode(int val, link sx, link dx);
int visita(link root, int len1, int len2);
void diameter(link root);
int max = 0;

int main()
{   link h = newNode(7,NULL,NULL);
    link f = newNode(8,NULL,NULL);
    link g = newNode(6,NULL,h);
    link d = newNode(4,f,NULL);
    link e = newNode(5,g,NULL);
    link b = newNode(2,d, e);
    link c = newNode(3,NULL,NULL);
    link a = newNode(1,b,c);

    diameter(a);
    printf("%d", max);

    return 0;
}

void diameter(link root){
int diametro = 0, len1 = 0, len2 = 0;

diametro = visita(root->left,len1,len2);
diametro += visita(root->right,len1,len2);

diametro+=2;

if(diametro>max)
   max = diametro;

if(root->left!=NULL) diameter(root->left);
if(root->right!=NULL) diameter(root->right);

}
int visita(link root, int len1, int len2){

if(root == NULL) return -1;

len1 = visita(root->left, len1,len2);
len2 = visita(root->right, len1, len2);

if(len1>len2) return len1+1;
else return len2+1;

}

link newNode(int val, link sx, link dx){
link x = malloc(sizeof(*x));
x->val = val;
x->left = sx;
x->right = dx;
return x;
}
