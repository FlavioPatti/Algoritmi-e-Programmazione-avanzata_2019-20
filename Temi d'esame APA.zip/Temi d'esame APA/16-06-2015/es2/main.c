#include <stdio.h>
#include <stdlib.h>

typedef struct node *link;
struct node{
int val;
link sx;
link dx;
};
link newNode(int val, link sx, link dx);
void doubleTree(link root);
void printTree(link root);

int main()
{
    link b = newNode(1, NULL, NULL);
    link c = newNode(3, NULL, NULL);
    link a = newNode(2, b, c);
    printTree(a);
    printf("\n");
    doubleTree(a);
    printTree(a);

    return 0;
}
void printTree(link root){
printf("%d ", root->val);
if(root->sx!=NULL) printTree(root->sx);
if(root->dx!=NULL) printTree(root->dx);
}
void doubleTree(link root){
    if(root==NULL) return;

    doubleTree(root->sx);
    doubleTree(root->dx);

    root->sx = newNode(root->val, root->sx, NULL);

}

link newNode(int val, link sx, link dx){
    link x = malloc(sizeof(*x));
    x->val = val;
    x->sx = sx;
    x->dx = dx;
    return x;
}
