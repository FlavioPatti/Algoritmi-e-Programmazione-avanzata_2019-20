#include <stdio.h>
#include <stdlib.h>

void mul (int *v1, int *v2, int n);

int main()
{
    int v1[3] = {0,3,2};
    int v2[3] = {2,4,3};

    mul(v1,v2,3);


    return 0;
}

void mul (int *v1, int *v2, int n){
int i, j, rip=0,flag = 0, val;
int r=0, c;
int *ris = calloc(2*n, sizeof(int));
int **mul = calloc(n,sizeof(int *));
for(i=0; i<n; i++) mul[i] = calloc(2*n, sizeof(int));

for(j=n-1; j>=0; j--){ //j=v2
        c=2*n-r-1;
    for(i=n-1; i>=0; i--){ //i=v1
            val = v2[j]*v1[i];
        if(val>9){
                val = val-10;
                flag = 1;
            }else flag = 0;
        if(rip == 0) mul[r][c--] = val;
        else mul[r][c--]= val+1;
        if(flag==1) rip = 1;
        else rip = 0;
        }
    r++;
}
for(i=0;i<n;i++){
    for(j=0; j<2*n; j++){
        printf("%d ", mul[i][j]);
    }
    printf("\n");
    }

printf("\n");
    for(j=2*n-1; j>=0; j--){
        for(i=0; i<n; i++){
            ris[j] = ris[j]+mul[i][j];
        }
            if(ris[j]>9){
             ris[j]=ris[j]-10;
             ris[j-1]++;
            }
        }
for(i=0; i<2*n;i++) printf("%d ", ris[i]);

}
