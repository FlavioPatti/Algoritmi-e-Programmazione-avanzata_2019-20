#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct prodotto *link;
typedef struct produttore *next;

//lista di liste

struct prodotto{ //colonne
    char *nome_prodotto;
    int prezzo;
    link prossimo_prodotto;
};

struct produttore{ //righe
    char *nome_produttore;
    link prodotti;
    next prossimo_produttore;
};

link newProdotto(char *nome_prodotto, int prezzo, link prossimo_prodotto);
next newProduttore(char *nome_produttore, link prodotti, next prossimo_produttore);
next inizializzaLista();
void printLista(next lista);
void prezzoProdotto(next lista, char *nomeProduttore, char *nomeProdotto);

int main()
{
    next lista;
    lista = inizializzaLista();
    printLista(lista);
    prezzoProdotto(lista, "Flavio", "Divano");
    prezzoProdotto(lista, "Ignazio", "Tappeto");
    prezzoProdotto(lista, "Flavio", "Stocazzo");

    return 0;
}

void prezzoProdotto(next lista, char *nomeProduttore, char *nomeProdotto){
    link x;
    int flag = 0;
    if(strcmp(lista->nome_produttore, nomeProduttore)==0){
        for(x=lista->prodotti; x!=NULL; x= x->prossimo_prodotto){
            if(strcmp(x->nome_prodotto, nomeProdotto)==0){
                flag = 1;
                printf("%d\n", x->prezzo);
            }
        }
        if(flag==0) printf("prodotto non trovato\n");
    }else { prezzoProdotto(lista->prossimo_produttore, nomeProduttore, nomeProdotto);
        }
}


void printLista(next lista){
next x;
link y;
for(x=lista; x!=NULL; x= x->prossimo_produttore){
    printf("%s ", x->nome_produttore);
    for(y=x->prodotti; y!=NULL; y=y->prossimo_prodotto){
        printf("%s ", y->nome_prodotto);
    }
    printf("\n");
    }
}

link newProdotto(char *nome_prodotto, int prezzo, link prossimo_prodotto){
link x = malloc(sizeof(x));
x->nome_prodotto = strdup(nome_prodotto);
x->prezzo = prezzo;
x->prossimo_prodotto = prossimo_prodotto;
return x;
}
next newProduttore(char *nome_produttore, link prodotti, next prossimo_produttore){
next x = malloc(sizeof(x));
x->nome_produttore = strdup(nome_produttore);
x->prodotti = prodotti;
x->prossimo_produttore = prossimo_produttore;
return x;
}

next inizializzaLista(){

link x = newProdotto("Tappeto", 100, NULL);
link y = newProdotto("Dado", 70, x);
next prod3 = newProduttore("Ignazio", y, NULL);

link a = newProdotto("Torta", 13, NULL);
link b = newProdotto("Divano", 15, a);
link c = newProdotto("Birra", 20, b);
next prod2 = newProduttore("Flavio", c, prod3);

link d = newProdotto("Palla", 25, NULL);
link e = newProdotto("Cassa", 30, d);
next prod1 = newProduttore("Alessio", e, prod2);

return prod1;

}
