#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef struct {
int v;
int w;
int wt;
}Edge;

void powerset(Edge* ed, int nv, int ne, int* sol, int pos);
int peso_minimo = INT_MAX;

int main()
{
    int nV = 5;
    int nE = 6;
    Edge* edges = malloc(nE*sizeof(Edge));
    edges[0].v=0;
    edges[0].w=1;
    edges[0].wt=5;
    edges[1].v=1;
    edges[1].w=4;
    edges[1].wt=1;
    edges[2].v=2;
    edges[2].w=0;
    edges[2].wt=3;
    edges[3].v=2;
    edges[3].w=3;
    edges[3].wt=1;
    edges[4].v=2;
    edges[4].w=4;
    edges[4].wt=2;
    edges[5].v=3;
    edges[5].w=4;
    edges[5].wt=4;
    int *sol = malloc(nE*sizeof(int));

    powerset(edges,nV,nE,sol,0);

    return 0;
}

int verifica(Edge* ed, int nv, int ne, int* sol){
int i, sum = 0;
int *mark = calloc(nv,sizeof(int));
for(i=0; i<ne; i++){
    if(sol[i]==1){
        mark[ed[i].v]=1;
        mark[ed[i].w]=1;
        sum+=ed[i].wt;
    }
}
for(i=0; i<nv; i++){
    if(mark[i]==0) return 0;
}

if(sum<peso_minimo){
    peso_minimo = sum;
    return 1;
}
return 0;
}

void powerset(Edge* ed, int nv, int ne, int* sol, int pos){
int i;
if(pos>=ne){
    if(verifica(ed,nv,ne,sol)){
    for(i=0; i<ne; i++) printf("%d ", sol[i]);
    printf("\n");
    return;
    }
    return;
}
sol[pos]=0;
powerset(ed,nv,ne,sol,pos+1);
sol[pos]=1;
powerset(ed,nv,ne,sol,pos+1);
}
