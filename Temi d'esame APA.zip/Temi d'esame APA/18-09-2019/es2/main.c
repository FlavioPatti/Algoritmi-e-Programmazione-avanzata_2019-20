#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct node* linkT;
typedef struct nodo* linkL;
struct nodo{
char str[10];
linkL next;
};
struct node{
char str[10];
linkT sx;
linkT dx;
};
linkT newNodeT(char *str, linkT sx, linkT dx);
linkL newNodeL(char *str, linkL next);
linkL tree2List(linkT root, int visit);
void stampa(linkL root);
linkL head = NULL;
int main()
{
    linkT g = newNodeT("Sette",NULL,NULL);
    linkT f = newNodeT("Sei", NULL,NULL);
    linkT e = newNodeT("Cinque", NULL,NULL);
    linkT d = newNodeT("Quattro", f,g);
    linkT c = newNodeT("Tre", NULL,e);
    linkT b = newNodeT("Due", d, NULL);
    linkT a = newNodeT("Uno", b,c);

    linkL x, A_rev = NULL;

    printf("Visita in order:\n");
    linkL A = tree2List(a,1);

    for(x = A; x!=NULL; x= x->next)
    A_rev = newNodeL(x->str, A_rev);

    stampa(A_rev);

    return 0;
}

linkL tree2List(linkT root, int visit){
    linkL x;
    if( root == NULL ) return NULL;
if(visit == 1){
    tree2List(root->sx, visit);
    head = newNodeL(root->str,head);
    tree2List(root->dx, visit);
}
if(visit == 2){
    head = newNodeL(root->str, head);
    tree2List(root->sx, visit);
    tree2List(root->dx, visit);
}

if(visit == 3){
    tree2List(root->sx, visit);
    tree2List(root->dx, visit);
    head = newNodeL(root->str, head);
}

return head;
}

void stampa(linkL root){
linkL x;
for(x=root; x!=NULL; x= x->next) printf("%s ", x->str);
printf("\n");
}
linkL newNodeL(char *str, linkL next){
linkL x = malloc(sizeof(*x));
strcpy(x->str, str);
x->next = next;
return x;
}

linkT newNodeT(char *str, linkT sx, linkT dx){
linkT x = malloc(sizeof(*x));
strcpy(x->str, str);
x->sx = sx;
x->dx= dx;
return x;
}
