#include <stdio.h>
#include <stdlib.h>



typedef struct col_t{
float val;
int col;
struct col_t *next;
}colonna_t;

typedef struct {
colonna_t *head;
int nEl;
}riga_t;

typedef struct {
    int NR;
riga_t *righe;
}matr_t;


matr_t* initMat(int nr);
void MATwrite(matr_t *M, int r, int c, float val);
void stampaMat(matr_t *M);
colonna_t* newNode(float val, int col, colonna_t * next);

int main()
{
    matr_t *M = initMat(4);
    MATwrite(M, 3, 2, 2.1);
    MATwrite(M, 3, 1, 2.2);
    MATwrite(M, 1, 3, 3.4);
    MATwrite(M, 3, 3, 2.3);


    stampaMat(M);

    return 0;
}

matr_t* initMat(int nr){
    int i;

matr_t *M = malloc(sizeof(*M));
M->NR = nr;
M->righe = malloc(M->NR*sizeof(riga_t));

for(i=0; i<M->NR; i++){
    M->righe[i].head = NULL;
    M->righe[i].nEl = 0;
    }
    return M;
}

colonna_t* newNode(float val, int col, colonna_t * next){
    colonna_t *x = malloc(sizeof(*x));
    x->val = val;
    x->col = col;
    x->next = next;

    return x;
}

void MATwrite(matr_t *M, int r, int c, float val){
    colonna_t *x = M->righe[r].head;
    colonna_t *t, *p = NULL;

    while(x!=NULL && x->col < c){
        p = x;
        x= x->next;
    }
    if(x==M->righe[r].head){ //primo in lista
        t = newNode(val, c, M->righe[r].head);
        M->righe[r].head = t;
    }else{
        t = newNode(val, c, x);
        p->next = t;
    }

    M->righe[r].nEl++;
}

void stampaMat(matr_t *M){
    int i;
    colonna_t *x;

    for(i=0; i<M->NR; i++){
        printf("Riga %d: ", i);
        x = M->righe[i].head;
    while(x!=NULL){
        printf("colonna: %d, valore: %0.2f ", x->col, x->val);
        x= x->next;
        }
        printf("\n");
    }
}
